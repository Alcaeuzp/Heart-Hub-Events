<?php
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedNamespaceFound -- HeartHub is the established plugin vendor prefix; retain existing class names for integrations.
namespace HeartHub\EventRegistrations;

defined( 'ABSPATH' ) || exit;

/**
 * Native public calendar rendered by [hherm_events_calendar].
 */
final class Calendar_Display {
	private $settings;

	public function __construct( Settings $settings ) {
		$this->settings = $settings;
	}

	public function register(): void {
		add_shortcode( 'hherm_events_calendar', array( $this, 'shortcode' ) );
	}

	public function shortcode( $attributes = array() ): string {
		$attributes = shortcode_atts( array( 'title' => '', 'show_title' => '' ), (array) $attributes, 'hherm_events_calendar' );
		$options = Calendar_Settings::get();
		$timezone = wp_timezone();
		$current_month = new \DateTimeImmutable( 'first day of this month 00:00:00', $timezone );
		$today = new \DateTimeImmutable( 'today', $timezone );
		$month = $this->requested_month( $current_month, $options );
		$first_weekday = (int) $options['week_start'];
		$offset = ( (int) $month->format( 'w' ) - $first_weekday + 7 ) % 7;
		$grid_start = $month->modify( '-' . $offset . ' days' );
		$weekdays = $this->weekdays( $first_weekday );
		$events = $this->events_for_month( $month, $options );
		$show_heading = '' === (string) $attributes['show_title'] ? (bool) $options['show_heading'] : 'true' === strtolower( (string) $attributes['show_title'] );
		$title = sanitize_text_field( (string) $attributes['title'] ) ?: sanitize_text_field( (string) $options['heading'] );
		$base_url = remove_query_arg( array( 'hherm_calendar_month' ) );
		$previous = $month->modify( '-1 month' );
		$next = $month->modify( '+1 month' );
		$current_index = (int) $current_month->format( 'Y' ) * 12 + (int) $current_month->format( 'n' );
		$month_index = (int) $month->format( 'Y' ) * 12 + (int) $month->format( 'n' );
		$can_previous = $month_index > $current_index - (int) $options['months_behind'];
		$can_next = $month_index < $current_index + (int) $options['months_ahead'];

		wp_enqueue_style( 'hherm-calendar-display', HHERM_URL . 'assets/calendar-display.css', array( 'hherm-event-public' ), HHERM_VERSION );
		wp_enqueue_script( 'hherm-calendar-display', HHERM_URL . 'assets/calendar-display.js', array(), HHERM_VERSION, true );

		ob_start();
		?>
		<div class="hherm-calendar" data-hherm-calendar="1" data-popups="<?php echo esc_attr( (string) (int) $options['show_popups'] ); ?>" data-density="<?php echo esc_attr( $this->density( $options ) ); ?>" style="<?php echo esc_attr( $this->calendar_style( $options ) ); ?>">
			<?php if ( $show_heading && $title ) : ?><h2 class="hherm-calendar__title"><?php echo esc_html( $title ); ?></h2><?php endif; ?>
			<div class="hherm-calendar__toolbar">
				<div class="hherm-calendar__month" aria-live="polite"><?php echo esc_html( wp_date( 'F Y', $month->getTimestamp(), $timezone ) ); ?></div>
				<nav class="hherm-calendar__navigation" aria-label="Calendar month navigation">
					<?php if ( $can_previous ) : ?><a class="hherm-calendar__nav-button" href="<?php echo esc_url( add_query_arg( 'hherm_calendar_month', $previous->format( 'Y-m' ), $base_url ) ); ?>" rel="prev" aria-label="Previous month">‹ <span>Previous</span></a><?php else : ?><span class="hherm-calendar__nav-button is-disabled" aria-disabled="true">‹ <span>Previous</span></span><?php endif; ?>
					<a class="hherm-calendar__nav-button hherm-calendar__nav-button--today" href="<?php echo esc_url( $base_url ); ?>">Today</a>
					<?php if ( $can_next ) : ?><a class="hherm-calendar__nav-button" href="<?php echo esc_url( add_query_arg( 'hherm_calendar_month', $next->format( 'Y-m' ), $base_url ) ); ?>" rel="next" aria-label="Next month"><span>Next</span> ›</a><?php else : ?><span class="hherm-calendar__nav-button is-disabled" aria-disabled="true"><span>Next</span> ›</span><?php endif; ?>
				</nav>
			</div>
			<table class="hherm-calendar__table">
				<thead><tr><?php foreach ( $weekdays as $weekday ) : ?><th scope="col"><?php echo esc_html( $weekday ); ?></th><?php endforeach; ?></tr></thead>
				<tbody>
				<?php for ( $week = 0; $week < 6; $week++ ) : ?><tr>
					<?php for ( $day = 0; $day < 7; $day++ ) :
						$date = $grid_start->modify( '+' . ( $week * 7 + $day ) . ' days' );
						$date_key = $date->format( 'Y-m-d' );
						$classes = array( 'hherm-calendar__day' );
						if ( $date->format( 'Y-m' ) !== $month->format( 'Y-m' ) ) $classes[] = 'is-outside-month';
						if ( $date_key === $today->format( 'Y-m-d' ) ) $classes[] = 'is-today';
						$day_events = $events[ $date_key ] ?? array();
						?>
						<td class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" aria-label="<?php echo esc_attr( wp_date( 'l, j F Y', $date->getTimestamp(), $timezone ) ); ?>">
							<span class="hherm-calendar__day-number"><?php echo esc_html( $date->format( 'j' ) ); ?></span>
							<?php if ( $day_events ) : ?><ul class="hherm-calendar__events">
								<?php foreach ( $day_events as $event ) : ?>
									<li class="hherm-calendar__event hherm-calendar__event--<?php echo esc_attr( $event['type'] ); ?><?php echo $day >= 5 ? ' hherm-calendar__event--align-right' : ''; ?>">
										<?php $this->render_event( $event, $options ); ?>
									</li>
								<?php endforeach; ?>
							</ul><?php endif; ?>
						</td>
					<?php endfor; ?>
				</tr><?php endfor; ?>
				</tbody>
			</table>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	private function calendar_style( array $options ): string {
		$defaults = Calendar_Settings::defaults();
		$variables = array(
			'--hherm-calendar-ink'                    => 'calendar_ink',
			'--hherm-calendar-muted'                  => 'calendar_muted',
			'--hherm-calendar-accent'                 => 'calendar_accent',
			'--hherm-calendar-border'                 => 'calendar_border',
			'--hherm-calendar-surface'                => 'calendar_surface',
			'--hherm-calendar-weekday-background'     => 'weekday_background',
			'--hherm-calendar-event-background'       => 'event_background',
			'--hherm-calendar-event-text'             => 'event_text',
			'--hherm-calendar-opening-hours-accent'   => 'opening_hours_accent',
			'--hherm-calendar-community-visit-accent' => 'community_visit_accent',
			'--hherm-calendar-speech-accent'          => 'speech_accent',
		);
		$declarations = array();
		foreach ( $variables as $variable => $key ) {
			$color = isset( $options[ $key ] ) && is_scalar( $options[ $key ] ) ? sanitize_hex_color( (string) $options[ $key ] ) : false;
			$declarations[] = $variable . ':' . ( $color ?: $defaults[ $key ] );
		}
		$width = isset( $options['max_width'] ) && is_scalar( $options['max_width'] ) ? (string) $options['max_width'] : 'full';
		$width = in_array( $width, array( '720', '960', '1200', '1440' ), true ) ? $width . 'px' : '100%';
		$declarations[] = '--hherm-calendar-max-width:' . $width;
		return implode( ';', $declarations );
	}

	private function density( array $options ): string {
		$density = isset( $options['density'] ) && is_scalar( $options['density'] ) ? (string) $options['density'] : 'comfortable';
		return in_array( $density, array( 'compact', 'comfortable', 'spacious' ), true ) ? $density : 'comfortable';
	}

	private function requested_month( \DateTimeImmutable $current_month, array $options ): \DateTimeImmutable {
		$raw = isset( $_GET['hherm_calendar_month'] ) ? sanitize_text_field( wp_unslash( $_GET['hherm_calendar_month'] ) ) : '';
		$month = $current_month;
		if ( preg_match( '/^\d{4}-(0[1-9]|1[0-2])$/', $raw ) ) {
			$candidate = \DateTimeImmutable::createFromFormat( '!Y-m', $raw, wp_timezone() );
			$errors = \DateTimeImmutable::getLastErrors();
			if ( $candidate && ( false === $errors || ( 0 === $errors['warning_count'] && 0 === $errors['error_count'] ) ) ) {
				$month = $candidate;
			}
		}
		$current_index = (int) $current_month->format( 'Y' ) * 12 + (int) $current_month->format( 'n' );
		$month_index = (int) $month->format( 'Y' ) * 12 + (int) $month->format( 'n' );
		$minimum = $current_index - (int) $options['months_behind'];
		$maximum = $current_index + (int) $options['months_ahead'];
		if ( $month_index < $minimum ) $month = $current_month->modify( '-' . (int) $options['months_behind'] . ' months' );
		if ( $month_index > $maximum ) $month = $current_month->modify( '+' . (int) $options['months_ahead'] . ' months' );
		return $month->modify( 'first day of this month 00:00:00' );
	}

	private function events_for_month( \DateTimeImmutable $month, array $options ): array {
		$events = array();
		$start_key = sanitize_key( (string) $this->settings->get( 'event_start', 'start_date' ) ) ?: 'start_date';
		$end_key = sanitize_key( (string) $this->settings->get( 'event_end', 'end_date__time' ) ) ?: 'end_date__time';
		$venue_key = sanitize_key( (string) $this->settings->get( 'event_venue', 'venue' ) ) ?: 'venue';
		$month_start = $month->getTimestamp();
		$month_end = $month->modify( 'first day of next month' )->getTimestamp();
		$items = get_posts(
			array(
				'post_type'      => $this->post_type(),
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'meta_value_num',
				'meta_key'       => $start_key,
				'order'          => 'ASC',
				'fields'         => 'ids',
				'meta_query'     => array(
					array( 'key' => $start_key, 'value' => $month_start, 'compare' => '>=', 'type' => 'NUMERIC' ),
					array( 'key' => $start_key, 'value' => $month_end, 'compare' => '<', 'type' => 'NUMERIC' ),
				),
			)
		);
		foreach ( $items as $post_id ) {
			$start = Event_Datetime::timestamp( get_post_meta( $post_id, $start_key, true ) );
			if ( ! $start ) continue;
			$this->add_event( $events, $post_id, $start, Event_Datetime::timestamp( get_post_meta( $post_id, $end_key, true ) ), $venue_key );
		}

		$series = get_posts(
			array(
				'post_type'      => $this->post_type(),
				'post_status'    => array( 'draft', 'private', 'publish' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => array(
					array( 'key' => Calendar_Schedule::TYPE_META, 'compare' => 'EXISTS' ),
					array( 'key' => Calendar_Schedule::MASTER_META, 'value' => '1', 'compare' => '=' ),
				),
			)
		);
		foreach ( $series as $post_id ) {
			if ( 'publish' !== get_post_meta( $post_id, Calendar_Schedule::SCHEDULE_STATUS_META, true ) ) continue;
			$rule = get_post_meta( $post_id, Calendar_Schedule::RULE_META, true );
			if ( ! is_array( $rule ) ) continue;
			$dates = $this->recurring_dates( $rule, $month );
			foreach ( $dates as $date ) {
				foreach ( (array) ( $rule['slots'] ?? array() ) as $slot ) {
					$start_text = sanitize_text_field( (string) ( $slot['start'] ?? '' ) );
					if ( ! preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $start_text ) ) continue;
					$start = $this->local_timestamp( $date . ' ' . $start_text );
					if ( ! $start ) continue;
					$end_text = sanitize_text_field( (string) ( $slot['end'] ?? '' ) );
					$end = preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $end_text ) ? $this->local_timestamp( $date . ' ' . $end_text ) : 0;
					$this->add_event( $events, $post_id, $start, $end, $venue_key );
				}
			}
		}
		foreach ( $events as &$day_events ) {
			usort( $day_events, static function ( array $left, array $right ): int { return $left['start'] <=> $right['start']; } );
		}
		unset( $day_events );
		return $events;
	}

	private function recurring_dates( array $rule, \DateTimeImmutable $month ): array {
		$frequency = sanitize_key( (string) ( $rule['frequency'] ?? '' ) );
		$month_end = $month->modify( 'first day of next month' );
		$dates = array();
		if ( 'dates' === $frequency ) {
			foreach ( (array) ( $rule['dates'] ?? array() ) as $date ) {
				$date = sanitize_text_field( (string) $date );
				if ( $this->valid_date( $date ) && $date >= $month->format( 'Y-m-d' ) && $date < $month_end->format( 'Y-m-d' ) ) $dates[] = $date;
			}
			return array_values( array_unique( $dates ) );
		}
		$first_date = sanitize_text_field( (string) ( $rule['start_date'] ?? '' ) );
		if ( ! $this->valid_date( $first_date ) ) return array();
		$weekdays = array_map( 'absint', (array) ( $rule['weekdays'] ?? array() ) );
		$month_day = absint( $rule['month_day'] ?? 0 );
		$cursor = $month;
		$last = $month_end->modify( '-1 day' );
		while ( $cursor <= $last ) {
			$date = $cursor->format( 'Y-m-d' );
			if ( $date >= $first_date ) {
				$matches = ( 'daily' === $frequency )
					|| ( 'weekly' === $frequency && in_array( (int) $cursor->format( 'w' ), $weekdays, true ) )
					|| ( 'monthly' === $frequency && $month_day === (int) $cursor->format( 'j' ) );
				if ( $matches ) $dates[] = $date;
			}
			$cursor = $cursor->modify( '+1 day' );
		}
		return $dates;
	}

	private function add_event( array &$events, int $post_id, int $start, int $end, string $venue_key ): void {
		$date_key = wp_date( 'Y-m-d', $start, wp_timezone() );
		$type = sanitize_key( (string) get_post_meta( $post_id, Calendar_Schedule::TYPE_META, true ) );
		$description = (string) get_post_field( 'post_content', $post_id );
		$events[ $date_key ][] = array(
			'id'          => $post_id,
			'title'       => get_the_title( $post_id ),
			'start'       => $start,
			'end'         => $end,
			'venue'       => (string) get_post_meta( $post_id, $venue_key, true ),
			'description' => wp_strip_all_tags( $description ),
			'type'        => $type ?: 'event',
			'url'         => 'publish' === get_post_status( $post_id ) && ! metadata_exists( 'post', $post_id, Calendar_Schedule::MASTER_META ) ? get_permalink( $post_id ) : '',
		);
	}

	private function render_event( array $event, array $options ): void {
		$time = wp_date( Event_Datetime::TIME_FORMAT, $event['start'], wp_timezone() );
		if ( $event['end'] > $event['start'] ) $time .= ' – ' . wp_date( Event_Datetime::TIME_FORMAT, $event['end'], wp_timezone() );
		$popup_id = 'hherm-calendar-event-' . absint( $event['id'] ) . '-' . $event['start'];
		$label = trim( ( $options['show_times'] ? $time . ' ' : '' ) . $event['title'] );
		if ( $options['show_popups'] ) :
			?>
			<div class="hherm-calendar__event-card" data-hherm-event-card>
				<button class="hherm-calendar__event-trigger" type="button" aria-expanded="false" aria-controls="<?php echo esc_attr( $popup_id ); ?>" data-hherm-event-trigger>
					<?php if ( $options['show_times'] ) : ?><span class="hherm-calendar__event-time"><?php echo esc_html( $time ); ?></span><?php endif; ?>
					<span class="hherm-calendar__event-name"><?php echo esc_html( $event['title'] ); ?></span>
				</button>
				<div class="hherm-calendar__popup" id="<?php echo esc_attr( $popup_id ); ?>" role="region" aria-label="Details for <?php echo esc_attr( $event['title'] ); ?>" hidden>
					<strong class="hherm-calendar__popup-title"><?php echo esc_html( $event['title'] ); ?></strong>
					<time datetime="<?php echo esc_attr( wp_date( 'c', $event['start'], wp_timezone() ) ); ?>"><?php echo esc_html( wp_date( 'l, j F Y', $event['start'], wp_timezone() ) ); ?></time>
					<span class="hherm-calendar__popup-time"><?php echo esc_html( $time ); ?></span>
					<?php if ( $event['venue'] ) : ?><span class="hherm-calendar__popup-location"><?php echo esc_html( $event['venue'] ); ?></span><?php endif; ?>
					<?php if ( $event['description'] ) : ?><span class="hherm-calendar__popup-description"><?php echo esc_html( $event['description'] ); ?></span><?php endif; ?>
					<?php if ( $event['url'] ) : ?><a class="hherm-calendar__popup-link" href="<?php echo esc_url( $event['url'] ); ?>">Event details</a><?php endif; ?>
				</div>
			</div>
			<?php
		else :
			if ( $event['url'] ) : ?><a class="hherm-calendar__event-link" href="<?php echo esc_url( $event['url'] ); ?>"><?php echo esc_html( $label ); ?></a><?php else : ?><span class="hherm-calendar__event-label"><?php echo esc_html( $label ); ?></span><?php endif;
		endif;
	}

	private function local_timestamp( string $value ): int {
		$date = \DateTimeImmutable::createFromFormat( '!Y-m-d H:i', $value, wp_timezone() );
		$errors = \DateTimeImmutable::getLastErrors();
		return $date && ( false === $errors || ( 0 === $errors['warning_count'] && 0 === $errors['error_count'] ) ) && $date->format( 'Y-m-d H:i' ) === $value ? $date->getTimestamp() : 0;
	}

	private function valid_date( string $date ): bool {
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) return false;
		$parsed = \DateTimeImmutable::createFromFormat( '!Y-m-d', $date, wp_timezone() );
		$errors = \DateTimeImmutable::getLastErrors();
		return $parsed && ( false === $errors || ( 0 === $errors['warning_count'] && 0 === $errors['error_count'] ) ) && $parsed->format( 'Y-m-d' ) === $date;
	}

	private function weekdays( int $week_start ): array {
		$all = array( 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat' );
		if ( 1 === $week_start ) {
			array_shift( $all );
			$all[] = 'Sun';
		}
		return $all;
	}

	private function post_type(): string {
		return sanitize_key( (string) $this->settings->get( 'events_cpt', 'events' ) );
	}
}
