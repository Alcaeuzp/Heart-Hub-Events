<?php
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedNamespaceFound -- HeartHub is the established plugin vendor prefix; retain existing class names for integrations.
namespace HeartHub\EventRegistrations;

defined( 'ABSPATH' ) || exit;

/**
 * Admin screen for dated entries displayed by the JetEngine Events calendar.
 */
final class Calendar_Schedule {
	public const PAGE_SLUG = 'hherm-calendar-schedule';
	public const SAVE_ACTION = 'hherm_save_calendar_entry';
	public const TRASH_ACTION = 'hherm_trash_calendar_entry';
	public const TYPE_META = 'hherm_calendar_entry_type';
	private const TAXONOMY = 'event-category';
	private const TERM_SLUG = 'calendar-schedule';
	private const RETRY_PREFIX = 'hherm_calendar_retry_';

	private $settings;
	private $audit;
	private $hook_suffix = '';

	public function __construct( Settings $settings, Audit_Log $audit ) {
		$this->settings = $settings;
		$this->audit = $audit;
	}

	public function register(): void {
		add_action( 'admin_init', array( $this, 'ensure_category' ), 99 );
		add_action( 'admin_menu', array( $this, 'add_menu' ), 20 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_post_' . self::SAVE_ACTION, array( $this, 'handle_save' ) );
		add_action( 'admin_post_' . self::TRASH_ACTION, array( $this, 'handle_trash' ) );
	}

	public function ensure_category(): void {
		if ( taxonomy_exists( self::TAXONOMY ) ) {
			$this->calendar_term_id();
		}
	}

	public function add_menu(): void {
		$this->hook_suffix = (string) add_submenu_page(
			Admin_Page::MENU_SLUG,
			'Calendar Schedule',
			'Calendar Schedule',
			Plugin::CAPABILITY,
			self::PAGE_SLUG,
			array( $this, 'render' )
		);
	}

	public function enqueue_assets( string $hook_suffix ): void {
		if ( $hook_suffix !== $this->hook_suffix ) {
			return;
		}

		wp_enqueue_style( 'hherm-admin-base', HHERM_URL . 'assets/admin-base.css', array(), HHERM_VERSION );
		wp_enqueue_style( 'hherm-events', HHERM_URL . 'assets/events.css', array( 'hherm-admin-base' ), HHERM_VERSION );
		wp_enqueue_style( 'hherm-calendar-schedule', HHERM_URL . 'assets/calendar-schedule.css', array( 'hherm-admin-base' ), HHERM_VERSION );
	}

	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only filters and editor selection on a capability-protected screen; all changes use separate nonce-verified handlers.
	public function render(): void {
		$this->require_access();
		$post_type = $this->post_type();
		$entry_id = isset( $_GET['entry_id'] ) ? absint( wp_unslash( $_GET['entry_id'] ) ) : 0;
		$is_new = isset( $_GET['new'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['new'] ) );
		$editing = $entry_id || $is_new;
		$error = isset( $_GET['calendar_error'] ) ? sanitize_key( wp_unslash( $_GET['calendar_error'] ) ) : '';
		$retry_token = isset( $_GET['retry'] ) ? sanitize_key( wp_unslash( $_GET['retry'] ) ) : '';
		$retry_values = $retry_token ? get_transient( $this->retry_key( $retry_token ) ) : false;
		if ( $retry_token ) {
			delete_transient( $this->retry_key( $retry_token ) );
		}

		$entry = $entry_id ? get_post( $entry_id ) : null;
		if ( $entry_id && ( ! $entry || $entry->post_type !== $post_type || ! metadata_exists( 'post', $entry_id, self::TYPE_META ) ) ) {
			$entry = null;
			$entry_id = 0;
			$error = $error ?: 'entry_missing';
		}
		$values = $this->entry_values( $entry );
		if ( is_array( $retry_values ) ) {
			$values = array_merge( $values, $retry_values );
		}

		if ( $editing ) {
			$this->render_editor( $post_type, $entry_id, $values, $error );
			return;
		}

		$search = isset( $_GET['calendar_search'] ) ? sanitize_text_field( wp_unslash( $_GET['calendar_search'] ) ) : '';
		$status = isset( $_GET['calendar_status'] ) ? sanitize_key( wp_unslash( $_GET['calendar_status'] ) ) : '';
		$paged = max( 1, isset( $_GET['paged'] ) ? absint( wp_unslash( $_GET['paged'] ) ) : 1 );
		$allowed_statuses = array( 'publish', 'draft', 'future', 'private', 'pending' );
		$start_key = $this->meta_key( 'event_start', 'start_date' );
		$query = post_type_exists( $post_type ) ? new \WP_Query(
			array(
				'post_type'      => $post_type,
				'post_status'    => in_array( $status, $allowed_statuses, true ) ? $status : $allowed_statuses,
				'posts_per_page' => 20,
				'paged'          => $paged,
				's'              => $search,
				'meta_key'       => $start_key,
				'orderby'        => 'meta_value_num',
				'order'          => 'ASC',
				'meta_query'     => array(
					array(
						'key'     => self::TYPE_META,
						'compare' => 'EXISTS',
					),
				),
			)
		) : null;
		?>
		<div class="wrap hherm-events-wrap hherm-calendar-schedule-wrap">
			<header class="hherm-page-header">
				<div><span class="hherm-eyebrow">Heart Hub Events</span><h1>Calendar Schedule</h1><p>Manage dated opening periods, community visits, speeches, and other entries shown on the Events calendar.</p></div>
				<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG . '&new=1' ) ); ?>">Add calendar entry</a>
			</header>
			<?php if ( isset( $_GET['calendar_saved'] ) ) : ?><div class="notice notice-success is-dismissible"><p>Calendar entry saved. Published entries are available to the Events calendar.</p></div><?php endif; ?>
			<?php if ( isset( $_GET['calendar_trashed'] ) ) : ?><div class="notice notice-success is-dismissible"><p>Calendar entry moved to the trash.</p></div><?php endif; ?>
			<?php if ( ! post_type_exists( $post_type ) ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( sprintf( 'The “%s” post type is not registered. Confirm JetEngine is active and the Events CPT slug is correct.', $post_type ) ); ?></p></div>
			<?php elseif ( ! taxonomy_exists( self::TAXONOMY ) ) : ?>
				<div class="notice notice-error"><p>The event-category taxonomy is not registered. Calendar entries need it to receive the Calendar Schedule category.</p></div>
			<?php else : ?>
				<form class="hherm-calendar-filters" method="get"><input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_SLUG ); ?>"><label><span>Search entries</span><input type="search" name="calendar_search" value="<?php echo esc_attr( $search ); ?>" placeholder="Entry name or description"></label><label><span>Status</span><select name="calendar_status"><option value="">All statuses</option><?php foreach ( $allowed_statuses as $item ) : ?><option value="<?php echo esc_attr( $item ); ?>" <?php selected( $status, $item ); ?>><?php echo esc_html( ucfirst( $item ) ); ?></option><?php endforeach; ?></select></label><div class="hherm-filter-actions"><button class="button button-primary">Filter</button><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG ) ); ?>">Clear</a></div></form>
				<section class="hherm-list-card"><div class="hherm-table-wrap"><table class="widefat fixed striped"><thead><tr><th>Entry</th><th>Type</th><th>Date &amp; time</th><th>Location</th><th>Status</th><th>Actions</th></tr></thead><tbody>
				<?php if ( $query && $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); $post_id = get_the_ID(); $item_type = sanitize_key( (string) get_post_meta( $post_id, self::TYPE_META, true ) ); ?>
					<tr>
						<td><strong><?php echo esc_html( get_the_title( $post_id ) ); ?></strong></td>
						<td><?php echo esc_html( $this->type_label( $item_type ) ); ?></td>
						<td><?php echo esc_html( $this->display_range( $post_id ) ); ?></td>
						<td><?php echo esc_html( (string) get_post_meta( $post_id, $this->meta_key( 'event_venue', 'venue' ), true ) ?: '—' ); ?></td>
						<td><span class="hherm-post-status hherm-post-status--<?php echo esc_attr( get_post_status( $post_id ) ); ?>"><?php echo esc_html( ucfirst( get_post_status( $post_id ) ) ); ?></span></td>
						<td class="hherm-row-actions"><div class="hherm-row-action-buttons"><a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG . '&entry_id=' . $post_id ) ); ?>">Edit</a><?php if ( 'publish' === get_post_status( $post_id ) ) : ?><a class="button button-small" href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" target="_blank" rel="noopener">View Page</a><?php endif; ?><a class="button button-small hherm-delete-link" onclick="return confirm('Move this calendar entry to the trash?');" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => self::TRASH_ACTION, 'entry_id' => $post_id ), admin_url( 'admin-post.php' ) ), self::TRASH_ACTION . '_' . $post_id ) ); ?>">Trash</a></div></td>
					</tr>
				<?php endwhile; wp_reset_postdata(); else : ?><tr><td colspan="6" class="hherm-empty-cell">No calendar entries found.</td></tr><?php endif; ?>
				</tbody></table></div></section>
				<?php if ( $query && $query->max_num_pages > 1 ) : ?><nav class="hherm-list-pagination" aria-label="Calendar schedule pages"><?php echo wp_kses_post( paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'current' => $paged, 'total' => $query->max_num_pages, 'type' => 'list' ) ) ); ?></nav><?php endif; ?>
			<?php endif; ?>
		</div>
		<?php
	}
	// phpcs:enable WordPress.Security.NonceVerification.Recommended

	public function handle_save(): void {
		$this->require_access();
		check_admin_referer( self::SAVE_ACTION, 'hherm_calendar_nonce' );
		$request = wp_unslash( $_POST );
		$post_type = $this->post_type();
		$entry_id = absint( $request['entry_id'] ?? 0 );
		$is_new = ! $entry_id;
		if ( ! post_type_exists( $post_type ) ) {
			$this->redirect_error( 'post_type_missing', $entry_id, $request );
		}
		if ( ! taxonomy_exists( self::TAXONOMY ) ) {
			$this->redirect_error( 'taxonomy_missing', $entry_id, $request );
		}
		$existing_post = $entry_id ? get_post( $entry_id ) : null;
		if ( $entry_id && ( ! $existing_post || $existing_post->post_type !== $post_type || ! metadata_exists( 'post', $entry_id, self::TYPE_META ) || ! current_user_can( 'edit_post', $entry_id ) ) ) {
			$this->redirect_error( 'entry_missing', 0, $request );
		}

		$type = sanitize_key( $this->request_text( $request, 'calendar_entry_type' ) );
		$title = $this->request_text( $request, 'entry_title' );
		$start_input = $this->request_text( $request, 'start_date' );
		$end_input = $this->request_text( $request, 'end_date__time' );
		$venue = $this->request_text( $request, 'venue' );
		$description = $this->request_text( $request, 'description', true );
		$status_raw = $this->request_text( $request, 'post_status' );
		$status = in_array( $status_raw, array( 'draft', 'publish' ), true ) ? $status_raw : 'draft';
		$start_local = Event_Datetime::editor_storage( $start_input );
		$end_local = Event_Datetime::editor_storage( $end_input );
		if ( ! array_key_exists( $type, $this->types() ) ) {
			$this->redirect_error( 'invalid_type', $entry_id, $request );
		}
		if ( '' === $title ) {
			$this->redirect_error( 'title_required', $entry_id, $request );
		}
		if ( strlen( $title ) > 200 ) {
			$this->redirect_error( 'title_length', $entry_id, $request );
		}
		if ( null === $start_local || '' === $start_local ) {
			$this->redirect_error( 'start_required', $entry_id, $request );
		}
		if ( null === $end_local ) {
			$this->redirect_error( 'invalid_datetime', $entry_id, $request );
		}
		if ( $end_local && Event_Datetime::timestamp( $end_local ) <= Event_Datetime::timestamp( $start_local ) ) {
			$this->redirect_error( 'end_before_start', $entry_id, $request );
		}
		if ( '' === $venue ) {
			$this->redirect_error( 'venue_required', $entry_id, $request );
		}
		if ( strlen( $venue ) > 200 ) {
			$this->redirect_error( 'venue_length', $entry_id, $request );
		}
		if ( strlen( $description ) > 5000 ) {
			$this->redirect_error( 'description_length', $entry_id, $request );
		}

		$term_id = $this->calendar_term_id();
		if ( is_wp_error( $term_id ) ) {
			$this->redirect_error( 'category_failed', $entry_id, $request );
		}
		$post_data = array(
			'post_type'    => $post_type,
			'post_status'  => $status,
			'post_title'   => $title,
			'post_content' => $description,
		);
		if ( $entry_id ) {
			$post_data['ID'] = $entry_id;
			$result = wp_update_post( $post_data, true );
		} else {
			$post_data['post_author'] = get_current_user_id();
			$result = wp_insert_post( $post_data, true );
		}
		if ( is_wp_error( $result ) || ! $result ) {
			$this->redirect_error( 'save_failed', $entry_id, $request );
		}
		$entry_id = (int) $result;

		$start_key = $this->meta_key( 'event_start', 'start_date' );
		$end_key = $this->meta_key( 'event_end', 'end_date__time' );
		$venue_key = $this->meta_key( 'event_venue', 'venue' );
		$info_key = $this->meta_key( 'event_info', '_description' );
		$meta = array(
			'event_name'                => $title,
			self::TYPE_META             => $type,
			$start_key                  => Event_Datetime::storage( $start_local ),
			$end_key                    => Event_Datetime::storage( $end_local ),
			$venue_key                  => $venue,
			$info_key                   => $description,
			'event_date_status'         => 'confirmed',
			'event_schedule_status'     => 'scheduled',
			'expected_month'            => '',
			'registration_type'         => 'no_registration',
			'registration_enabled'      => 'false',
			'show_remaining_spots'      => 'false',
			'allow_waitlist'            => 'false',
			'show_what_to_expect'       => 'false',
			'show_interest_contact_button' => 'false',
		);
		foreach ( $meta as $key => $value ) {
			update_post_meta( $entry_id, $key, $value );
		}

		$existing_terms = wp_get_object_terms( $entry_id, self::TAXONOMY, array( 'fields' => 'ids' ) );
		if ( is_wp_error( $existing_terms ) ) {
			$this->redirect_error( 'category_failed', $entry_id, $request );
		}
		$term_ids = array_values( array_unique( array_merge( array_map( 'absint', $existing_terms ), array( $term_id ) ) ) );
		$assigned = wp_set_object_terms( $entry_id, $term_ids, self::TAXONOMY, false );
		if ( is_wp_error( $assigned ) ) {
			$this->redirect_error( 'category_failed', $entry_id, $request );
		}
		$this->audit->write( $entry_id, $is_new ? 'calendar_entry_created' : 'calendar_entry_updated', $status, array( 'post_type' => $post_type, 'entry_type' => $type, 'entry_title' => $title ) );

		wp_safe_redirect( add_query_arg( array( 'calendar_saved' => 1 ), admin_url( 'admin.php?page=' . self::PAGE_SLUG ) ) );
		exit;
	}

	public function handle_trash(): void {
		$this->require_access();
		$entry_id = isset( $_GET['entry_id'] ) ? absint( wp_unslash( $_GET['entry_id'] ) ) : 0;
		check_admin_referer( self::TRASH_ACTION . '_' . $entry_id );
		$post = $entry_id ? get_post( $entry_id ) : null;
		if ( ! $post || $post->post_type !== $this->post_type() || ! metadata_exists( 'post', $entry_id, self::TYPE_META ) || ! current_user_can( 'edit_post', $entry_id ) ) {
			wp_die( esc_html__( 'That calendar entry could not be moved to the trash.', 'heart-hub-event-registration-manager' ), esc_html__( 'Calendar entry unavailable', 'heart-hub-event-registration-manager' ), array( 'response' => 404 ) );
		}
		$result = wp_trash_post( $entry_id );
		if ( ! $result ) {
			wp_die( esc_html__( 'WordPress could not move the calendar entry to the trash.', 'heart-hub-event-registration-manager' ), esc_html__( 'Calendar entry update failed', 'heart-hub-event-registration-manager' ), array( 'response' => 500 ) );
		}
		$this->audit->write( $entry_id, 'calendar_entry_trashed', 'trashed', array( 'post_type' => $post->post_type, 'entry_title' => get_the_title( $entry_id ) ) );
		wp_safe_redirect( add_query_arg( 'calendar_trashed', 1, admin_url( 'admin.php?page=' . self::PAGE_SLUG ) ) );
		exit;
	}

	private function render_editor( string $post_type, int $entry_id, array $values, string $error ): void {
		?>
		<div class="wrap hherm-events-wrap hherm-calendar-schedule-wrap">
			<header class="hherm-page-header"><div><span class="hherm-eyebrow">Heart Hub Events</span><h1><?php echo esc_html( $entry_id ? 'Edit calendar entry' : 'Add calendar entry' ); ?></h1><p>Set the date, time, and location for an item on the Events calendar.</p></div><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG ) ); ?>">Back to schedule</a></header>
			<?php if ( $error ) : ?><div class="notice notice-error" role="alert"><p><?php echo esc_html( $this->error_message( $error ) ); ?></p></div><?php endif; ?>
			<?php if ( ! post_type_exists( $post_type ) ) : ?><div class="notice notice-error"><p><?php echo esc_html( sprintf( 'The “%s” post type is not registered. Confirm JetEngine is active and the Events CPT slug is correct.', $post_type ) ); ?></p></div>
			<?php elseif ( ! taxonomy_exists( self::TAXONOMY ) ) : ?><div class="notice notice-error"><p>The event-category taxonomy is not registered. Calendar entries need it to receive the Calendar Schedule category.</p></div>
			<?php else : ?>
				<form class="hherm-calendar-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ACTION ); ?>"><input type="hidden" name="entry_id" value="<?php echo esc_attr( $entry_id ); ?>"><?php wp_nonce_field( self::SAVE_ACTION, 'hherm_calendar_nonce' ); ?>
					<section class="hherm-form-card"><div class="hherm-calendar-form-grid">
						<label><span>Entry name <strong>*</strong></span><input type="text" name="entry_title" maxlength="200" required value="<?php echo esc_attr( $values['entry_title'] ); ?>" placeholder="For example, Open at Heart Hub"></label>
						<label><span>Type <strong>*</strong></span><select name="calendar_entry_type" required><?php foreach ( $this->types() as $type => $label ) : ?><option value="<?php echo esc_attr( $type ); ?>" <?php selected( $values['calendar_entry_type'], $type ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label>
						<label><span>Start date &amp; time <strong>*</strong></span><input type="datetime-local" name="start_date" required value="<?php echo esc_attr( $values['start_date'] ); ?>"><small>Uses the WordPress site timezone.</small></label>
						<label><span>End date &amp; time</span><input type="datetime-local" name="end_date__time" value="<?php echo esc_attr( $values['end_date__time'] ); ?>"><small>Optional. Leave blank for a single-time entry.</small></label>
						<label class="hherm-calendar-field--wide"><span>Location <strong>*</strong></span><input type="text" name="venue" maxlength="200" required value="<?php echo esc_attr( $values['venue'] ); ?>" placeholder="Venue, school, club, or address"></label>
						<label class="hherm-calendar-field--wide"><span>Description</span><textarea name="description" rows="5" maxlength="5000"><?php echo esc_textarea( $values['description'] ); ?></textarea></label>
						<label><span>Visibility</span><select name="post_status"><option value="publish" <?php selected( $values['post_status'], 'publish' ); ?>>Published — show on calendar</option><option value="draft" <?php selected( $values['post_status'], 'draft' ); ?>>Draft — keep off calendar</option></select></label>
					</div></section>
					<div class="hherm-calendar-form-actions"><button class="button button-primary" type="submit"><?php echo esc_html( $entry_id ? 'Save changes' : 'Add to calendar' ); ?></button><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG ) ); ?>">Cancel</a></div>
				</form>
				<p class="hherm-calendar-note">Entries are saved to the existing <code><?php echo esc_html( $post_type ); ?></code> post type, assigned the <strong>Calendar Schedule</strong> category, and marked as having no registration.</p>
			<?php endif; ?>
		</div>
		<?php
	}

	private function entry_values( $entry ): array {
		$values = array(
			'entry_title'          => $entry ? get_the_title( $entry ) : '',
			'calendar_entry_type'  => $entry ? sanitize_key( (string) get_post_meta( $entry->ID, self::TYPE_META, true ) ) : 'opening_hours',
			'start_date'           => $entry ? Event_Datetime::input( get_post_meta( $entry->ID, $this->meta_key( 'event_start', 'start_date' ), true ) ) : '',
			'end_date__time'       => $entry ? Event_Datetime::input( get_post_meta( $entry->ID, $this->meta_key( 'event_end', 'end_date__time' ), true ) ) : '',
			'venue'                => $entry ? (string) get_post_meta( $entry->ID, $this->meta_key( 'event_venue', 'venue' ), true ) : '',
			'description'          => $entry ? (string) $entry->post_content : '',
			'post_status'          => ! $entry || 'publish' === $entry->post_status ? 'publish' : 'draft',
		);
		foreach ( array( 'entry_title', 'calendar_entry_type', 'start_date', 'end_date__time', 'venue', 'post_status' ) as $key ) $values[ $key ] = sanitize_text_field( $values[ $key ] );
		$values['description'] = sanitize_textarea_field( $values['description'] );
		return $values;
	}

	private function display_range( int $entry_id ): string {
		$start = get_post_meta( $entry_id, $this->meta_key( 'event_start', 'start_date' ), true );
		$end = get_post_meta( $entry_id, $this->meta_key( 'event_end', 'end_date__time' ), true );
		$start_text = Event_Datetime::display( $start, Event_Datetime::DATETIME_FORMAT );
		$end_format = Event_Datetime::display( $start, 'Y-m-d' ) === Event_Datetime::display( $end, 'Y-m-d' ) ? Event_Datetime::TIME_FORMAT : Event_Datetime::DATETIME_FORMAT;
		$end_text = Event_Datetime::display( $end, $end_format );
		return $end_text ? $start_text . ' – ' . $end_text : ( $start_text ?: '—' );
	}

	private function calendar_term_id() {
		$term = get_term_by( 'slug', self::TERM_SLUG, self::TAXONOMY );
		if ( $term && ! is_wp_error( $term ) ) {
			return (int) $term->term_id;
		}
		$term = get_term_by( 'name', 'Calendar Schedule', self::TAXONOMY );
		if ( $term && ! is_wp_error( $term ) ) {
			return (int) $term->term_id;
		}
		$created = wp_insert_term( 'Calendar Schedule', self::TAXONOMY, array( 'slug' => self::TERM_SLUG, 'description' => 'Dated entries managed in Heart Hub Events > Calendar Schedule.' ) );
		if ( is_wp_error( $created ) ) {
			if ( 'term_exists' === $created->get_error_code() ) {
				$existing_id = $created->get_error_data();
				if ( is_array( $existing_id ) ) {
					$existing_id = $existing_id['term_id'] ?? reset( $existing_id );
				}
				return absint( $existing_id );
			}
			return $created;
		}
		return absint( $created['term_id'] ?? 0 );
	}

	private function retry_key( string $token ): string {
		return self::RETRY_PREFIX . get_current_user_id() . '_' . sanitize_key( $token );
	}

	private function redirect_error( string $code, int $entry_id = 0, array $request = array() ): void {
		$args = array( 'calendar_error' => sanitize_key( $code ) );
		if ( $entry_id ) {
			$args['entry_id'] = $entry_id;
		}
		$token = '';
		if ( $request ) {
			$token = wp_generate_password( 12, false, false );
			$retry_values = array(
			'entry_title'         => $this->request_text( $request, 'entry_title' ),
			'calendar_entry_type' => sanitize_key( $this->request_text( $request, 'calendar_entry_type' ) ) ?: 'opening_hours',
			'start_date'          => $this->request_text( $request, 'start_date' ),
			'end_date__time'      => $this->request_text( $request, 'end_date__time' ),
			'venue'               => $this->request_text( $request, 'venue' ),
			'description'         => $this->request_text( $request, 'description', true ),
			'post_status'         => in_array( $this->request_text( $request, 'post_status' ), array( 'draft', 'publish' ), true ) ? $this->request_text( $request, 'post_status' ) : 'draft',
			);
			set_transient( $this->retry_key( $token ), $retry_values, 10 * MINUTE_IN_SECONDS );
			$args['retry'] = $token;
			if ( ! $entry_id ) {
				$args['new'] = 1;
			}
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php?page=' . self::PAGE_SLUG ) ) );
		exit;
	}

	private function error_message( string $code ): string {
		$messages = array(
			'post_type_missing' => 'The Events post type is not available.',
			'taxonomy_missing'  => 'The event-category taxonomy is not available.',
			'entry_missing'     => 'That calendar entry could not be found or edited.',
			'invalid_type'      => 'Choose a valid calendar entry type.',
			'title_required'    => 'Enter an entry name.',
			'title_length'      => 'Entry names must be 200 characters or fewer.',
			'start_required'    => 'Enter a valid start date and time.',
			'invalid_datetime'  => 'Enter a valid start or end date and time.',
			'end_before_start'  => 'The end date and time must be later than the start.',
			'venue_required'    => 'Enter a location.',
			'venue_length'      => 'Locations must be 200 characters or fewer.',
			'description_length'=> 'Descriptions must be 5,000 characters or fewer.',
			'category_failed'   => 'The Calendar Schedule category could not be assigned. Confirm the event-category taxonomy is available.',
			'save_failed'       => 'WordPress could not save the calendar entry. Please try again.',
		);
		return $messages[ $code ] ?? 'The calendar entry could not be saved. Please check the form and try again.';
	}

	private function types(): array {
		return array(
			'opening_hours'  => 'Opening hours',
			'community_visit' => 'Community visit',
			'speech'         => 'Speech / presentation',
			'other'          => 'Other',
		);
	}

	private function type_label( string $type ): string {
		$types = $this->types();
		return $types[ $type ] ?? 'Other';
	}

	private function meta_key( string $setting, string $default ): string {
		return sanitize_key( (string) $this->settings->get( $setting, $default ) ) ?: $default;
	}

	private function request_text( array $request, string $key, bool $textarea = false ): string {
		$value = $request[ $key ] ?? '';
		if ( ! is_scalar( $value ) ) {
			return '';
		}
		return $textarea ? sanitize_textarea_field( (string) $value ) : sanitize_text_field( (string) $value );
	}

	private function post_type(): string {
		return sanitize_key( (string) $this->settings->get( 'events_cpt', 'events' ) );
	}

	private function require_access(): void {
		if ( ! current_user_can( Plugin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage the calendar schedule.', 'heart-hub-event-registration-manager' ), esc_html__( 'Access denied', 'heart-hub-event-registration-manager' ), array( 'response' => 403 ) );
		}
	}
}
