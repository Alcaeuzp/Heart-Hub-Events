=== Heart Hub Event Registration Manager ===

Requires at least: 6.4

Tested up to: 7.1.1

Requires PHP: 7.4

Stable tag: 1.21.0

License: GPLv2 or later



Private WordPress admin dashboard for reviewing JetEngine CCT event applications for Heart Hub South West.



Developed by Paul Els.

== Features ==

* Reads existing Event Registrations through JetEngine's supported CCT API.

* Loads the Event filter directly from WordPress posts registered under `post_type=events`.

* Creates draft or published `events` posts through a dedicated, validated admin form mapped to the existing JetEngine event fields.

* Lists and edits existing `events` posts without exposing JetEngine's native CPT editor.

* Assigns and manages the existing `event-category` taxonomy through the plugin interface.

* Configures confirmed Website Registration events with one authoritative Registration enabled switch, while External Registration uses its saved URL automatically and No Registration displays no registration CTA.

* Locks website registration for Date TBC events and optionally replaces Register Now with a Contact Us-for-interest button until the date is confirmed.

* Supplies JetEngine-template shortcodes for the event date, registration/contact CTA, remaining spots, and What to Expect section with backward-compatible defaults.

* Separates fundraising events into a dedicated Fundraisers admin screen while retaining the shared Events post type, registration workflow, and categories.

* Captures fundraiser costs and optional raffle pricing at creation, then records the authoritative `amount_raised` value after creation and shows funds raised plus confirmed attendance in the fundraiser list and overview.

* Supplies rolling-period and per-event shortcodes for funds raised, people attending, and events run.

* Organises the full-width Settings screen into Emails, Appearance, Contact & Access, Event Setup, and Shortcodes tabs.

* Reserves capacity immediately for pending registrations using their configurable attendee count.

* Keeps approved reservations in place and returns capacity exactly once when an application is declined.

* Prevents over-capacity registrations and protects capacity changes with short-lived event locks.

* Places the complete registration on the waitlist when it will not fit and the event has `allow_waitlist` enabled.

* Filters waitlisted applications in the admin and allows approval only after enough capacity becomes available.

* Provides an event-specific attendance register for approved registrations with name, phone, email, reason, and group size.

* Records `attendance_status` as `attended`, `no-show`, `partial`, or `unknown`, with audited bulk updates.

* Generates revocable event-specific QR check-in links that open at the event start and expire one hour after the event ends.

* Lets approved attendees verify with their registration email, self-record attendance, and submit optional feedback.

* Shows the same staff-directed register error when the email is not registered for that event or the registration has not been approved.

* Protects public check-in with unguessable tokens, expiry enforcement, nonces, a honeypot, generic failures, layered hashed-IP rate limiting, and anti-framing/privacy headers.

* Stores feedback on the registration CCT record using the configurable `event_feedback` field key.

* Provides a Feedback & Analytics admin screen with attendance totals and event-level feedback review.

* Lets administrators enable or disable approval, decline, waitlist, cancellation, and feedback emails independently and tune each delay in minutes, hours, or days.

* Queues delayed event-triggered messages without storing recipient data in cron arguments, revalidates the registration before delivery, and retries transient transport failures.

* Runs an hourly, idempotent post-event check and sends attended or partially attended registrations a feedback request after the configured delay when no response exists.

* Provides secure 90-day attendee-specific feedback links with rating and optional comments.

* Provides shared temporary-page settings for the header logo/text, footer, page/card/text/button/border colours, and principal check-in, feedback, and attendance-management copy.

* Uses the same sanitized theme across check-in, feedback, and registration-management links, with cache-safe assets and contrast warnings in Settings.

* Initializes hidden `current_event_capacity` from `event_capacity` on creation and maintains it without exposing an editable field.

* Recalculates hidden current capacity to the new total when an unpublished event with no reservations is edited.

* Enforces event publication, registration-enabled, open/close, cancellation, and capacity rules on the server before accepting a form registration.

* Cancels events without deleting them, disables new registrations, and emails or queues pending, approved, and waitlisted registrations.

* Provides an editable, previewable event-cancellation email and safely retries only recipients whose real email was not already sent.

* Adds a Media Library header-icon picker and renders the selected icon in every branded email header.

* Provides an optional reusable rich-text signature inserted with `{signature}` or `[email_signature]`.

* Creates and edits the `parking_access` textarea and JetEngine `what_to_expect` repeater with `title`/`content` subfields.

* Limits What to Expect to six complete entries with matching browser and server validation.

* Lists applications with protected server-side pagination.

* Searches applicant names and email addresses.

* Filters by event, status, and registration date range, with date sorting.

* Shows the complete applicant and related event details in an accessible modal.

* Adds the Heart Hub South West admin design system across the plugin screens.

* Provides registration stat cards, quick filters, row selection, bulk approval/decline, and CSV export.

* Combines QR generation, the attendee-page preview, protected live check-in polling, and the attendance register on one Attendance & Check-in screen.

* Sends and previews a dedicated waitlist email template with a party-size placeholder.

* Approves or declines pending applications and records reviewer/date/notes.

* Sends or safely logs branded decision emails without emailing on view.

* Provides editable approval, decline, waitlist, cancellation, and post-event feedback subjects and rich-text bodies with data placeholders.

* Adds a sticky email-template navigator and save action for faster editing across all message types.

* Provides sandboxed rendered email previews and safe logo/colour controls.

* Records decisions and email outcomes in a plugin-owned audit table.



== Installation ==

1. Upload this directory to wp-content/plugins and activate it.

2. Open Heart Hub Events > Settings > Event Setup and enter the live Events CPT, relation ID, and event meta keys.

3. Confirm the default capacity keys: CCT `number_of_attendees` and event meta `current_event_capacity`.

4. Select the nominated owner role. That role can review registrations and manage events when it also has the Events post type's create/edit capabilities. Administrators receive the plugin capability automatically.

5. Open Heart Hub Events > Registrations in the WordPress admin menu to access the application dashboard.

6. Use Heart Hub Events > Events to view or edit existing event posts, and use the Create Event button there to add one.

7. Use Event Categories under Heart Hub Events > Settings > Event Setup to manage the existing `event-category` taxonomy. Fundraising Event, Community Outreach, and Mindfulness Workshop are locked because site templates and workflows depend on them; new categories may require dynamic configuration changes.

8. Use Heart Hub Events > Attendance & Check-in to select an event, generate its QR link, monitor live check-ins, and record attendance for approved registrations.

9. Add the Events CPT Number field `amount_raised`, and add the CCT textarea field `event_feedback`, numeric field `feedback_score`, and datetime/text field `checked_in_at`, or configure the feedback text key in Heart Hub Events > Settings.

10. Configure automatic email timings and templates under Settings > Emails, and temporary attendee-page branding under Settings > Appearance.

11. Generate an event-day QR link from Attendance & Check-in; feedback is reviewed under Feedback & Analytics.

12. Add the JetFormBuilder Call Hook `heart_hub_registration_created` to form 2774 before its CCT insert action.

13. Leave Email mode as Log only until dry-run output has been approved.



The plugin creates only its own audit table. During normal operation it does not alter or delete the Events CPT, Event Registrations CCT, forms, pages, listings, or queries.



The management dashboard is available only inside `/wp-admin/` to logged-in users with the dedicated event-registration capability. The plugin does not create a competing WordPress frontend page; its event-display shortcodes are intended for the existing JetEngine cards and single-event template. It also renders temporary standalone check-in, registration-management, and feedback views only for valid bearer links. The check-in view opens at the event start and closes one hour after the event ends; management and feedback links enforce their own expiry windows.



Use Heart Hub Events > Settings > Emails to edit automatic delivery, approval, decline, waitlist, event-cancellation, and post-event feedback templates, adjust safe brand colours/logo, and view exact rendered previews. Template placeholders insert authoritative applicant and event data at send time.



The Create Event address field reads the Google Maps API key and geocoding provider configured in JetEngine Maps Settings. When the browser key is available, the field provides Google address suggestions; on save, the address is checked through JetEngine's configured geocoder before it is stored as the existing JetEngine location-address string. If the Maps module is unavailable, the field falls back to full-address entry and preserves the existing workflow.



== Uninstallation ==

Use WordPress Plugins > Installed Plugins > Delete after deactivating the plugin. WordPress will run `uninstall.php` and remove only this plugin's settings (including email timing and temporary-page appearance), scheduled-email jobs, temporary review/capacity locks, temporary check-in/management/feedback links and rate limits, custom role capability, and audit table. The audit table is deleted because it can contain applicant email content and decision notes.



QRCode.js is bundled locally under its MIT licence so QR generation does not send attendee or event data to an external service.



Uninstallation never deletes or modifies the Events CPT, Event Registrations CCT or its records, JetEngine relations, JetFormBuilder forms, WordPress pages, Query Builder queries, or JetEngine listings.



== Changelog ==

= 1.21.0 =

* Removed the redundant Show Register Now Button toggle. Confirmed Website Registration events now use Registration enabled as the single source of truth for the Register Now CTA.
* Automatically enables Registration enabled when the user selects Website Registration or changes a Website Registration event from Date TBC to Date Confirmed. The user can still turn registration off manually afterward.
* Locks Registration enabled, remaining spots, and waiting-list controls off for Date TBC Website Registration events, with the message “As this event has no confirmed date, registration is locked.”
* Added Show Contact Us button for interest for Date TBC Website Registration events. It is disabled and cleared again when the date is confirmed.
* External Registration now displays its external CTA automatically while storing internal registration controls as off. No Registration displays no registration CTA.

= 1.20.3 =

* Defaulted Show Register Now Button and Show Remaining Spots off for new events while retaining Website Registration as the default registration type.
* Limited both switches to Website Registration in the form, save handler, event overview, and public shortcode output. External Registration and No Registration clear and disable both settings.
* Shortened the registration-type helper to “Website Registration is used when no type is supplied.”

= 1.20.2 =

* Locked the Fundraising Event, Community Outreach, and Mindfulness Workshop foundational categories in the plugin's category manager.
* Replaced their Edit/Delete actions with a Locked label and enforced the same restriction in the category update and deletion handlers. The categories remain assignable and their events remain editable.

= 1.20.1 =

* New fundraising events automatically receive the Fundraising Event category without showing the additional Categories selector.
* Extra categories remain available while editing an existing fundraiser, and new-fundraiser submissions ignore any manually supplied additional category IDs.

= 1.20.0 =

* Removed Amount raised from new-fundraiser creation; it is now available only while editing an existing fundraiser, when the final result can be recorded.
* Reordered Sponsorship cost and Registration fee onto one row, added an optional validated Raffle entry cost, and clarified that a blank cost means the raffle is simply available.
* Changed fundraiser amount displays and money inputs from pounds to dollars, including the fundraiser summary, list, and overview.
* Made confirmed-event start/end values genuinely optional in both the browser and save handler, and allowed a missing Registration Type to fall back to Website Registration.
* Defaulted Show What to Expect off for newly created events.
* Restyled the Event Type selector, kept required markers inline with their labels, and corrected the co-hosted switch layout and label colour.

= 1.19.6 =

* Registered Create Event and the other non-sidebar screens as directly accessible hidden admin routes instead of registering and then removing submenu entries.
* Fixed WordPress rejecting the Create Event URL before its capability-protected editor callback could run.

= 1.19.5 =

* Allowed configured owner roles to open the Events, Fundraisers, and Create Event routes instead of hitting WordPress's generic access-denied page.
* Retained the Events custom post type's own create/edit capability checks and kept Settings and event-category administration restricted to administrators.

= 1.19.4 =

* Funds-raised shortcodes now output the formatted number without any currency symbol. Add your preferred symbol directly before the shortcode in page content.
* Removed the currency shortcode attribute and updated the shortcode guidance. Decimal formatting and calculations are unchanged.

= 1.19.3 =

* Addressed Plugin Check findings for input sanitization, escaped form errors, prepared audit-table identifiers, and stylesheet/script loading.
* Kept existing class names, bearer links, admin filters, attendance rules, and registration workflows compatible; documented intentional read-only and plugin-owned database operations.
* Normalized PHP line endings and added the tested WordPress version reported by the site owner.
* Added a repeatable release build that excludes development notes, tests, tooling, and previous ZIP archives from the installable plugin.

= 1.19.2 =

* Corrected the Fundraising Event category lookup to use the live `fundraising-event` taxonomy slug.
* Kept the internal fundraising type identifier stable so existing editor submissions and plugin logic remain compatible.

= 1.19.1 =

* Completed pre-upload validation under PHP 7.4.33 and PHP 8.5.10, including full-plugin bootstrap and focused workflow tests.
* Declared optional check-in and email-service constructor dependencies explicitly nullable to avoid PHP 8.5 deprecation warnings.
* Repaired and expanded the regression harness for settings tabs, menu routing, plugin bootstrap, event display dependencies, and modern Reflection behavior.

= 1.19.0 =

* Rebuilt Settings as a full-width tabbed screen with Emails, Appearance, Contact & Access, Event Setup, and Shortcodes sections.
* Moved Email Templates into the Emails tab and removed its redundant sidebar entry while preserving the old route for bookmarks.
* Added an in-plugin reference for all impact and event-display shortcodes.
* Kept every core setting in one safe form so saving a tab does not reset values shown on another tab.

= 1.18.0 =

* Combined the attendance register, event-day QR controls, attendee-page preview, and live check-in feed under Attendance & Check-in.
* Removed the redundant Check-in Page and Create Event sidebar entries while retaining their internal routes for existing links.
* Moved Event Categories into Settings and added a warning that new categories may need help with the dynamic event configuration.

= 1.17.0 =

* Added a dedicated Fundraisers admin screen that lists only fundraising-category events; the Events screen now excludes those records.
* Added the `amount_raised` event meta field to the fundraiser editor, list, overview, validation, and JetEngine readiness check.
* Added rolling 12-month shortcodes for total fundraiser income, confirmed attendees, and events run.
* Added per-event shortcodes for fundraiser income and confirmed attendees, using QR/form check-in headcounts where available.

= 1.16.0 =

* Added per-event Website, External, and No Registration modes, including external URLs and an optional Contact Us CTA.
* Added independent Register Now, remaining-spots, and What to Expect display switches with backward-compatible ON defaults.
* Added Date Confirmed and Date TBC editing while retaining the existing scheduled/TBA metadata compatibility layer.
* Added front-end shortcodes for event date, registration CTA, remaining spots, and What to Expect so JetEngine templates can use the same rules.
* Hid Past Events and Past Fundraisers from the standard event category picker while preserving those lifecycle categories on edit.

= 1.15.0 =

* Added Scheduled and Date to be announced event states, optional expected month, and date-optional event creation.
* Added a JetFormBuilder expression-of-interest hook that stores interest records in the existing registration CCT and relation without reserving capacity.
* Added editable, delayed and audited date-confirmed emails for interested customers when a TBA event is scheduled.
* Added a JetEngine and JetFormBuilder setup guide for the new fields, visibility rules, form and test flow.

= 1.14.0 =
* Event type uses the existing event-category taxonomy: Workshop (standard/free) defaults for new events; Fundraising reveals registration_fee and sponsorship_cost text fields and the raffle switcher.
* Create categories with slugs workshop and fundraising-event, or names Workshop and Fundraising Event/Fundraising. Missing categories produce a clear save error rather than assigning an invented ID.
* Existing events with neither or both type categories default to Keep existing type/categories. Switching type preserves other categories, including Past Events. Fundraising metadata remains stored when switching to Workshop and reloads if switched back.
* Add JetEngine meta fields registration_fee (Text), sponsorship_cost (Text), and raffle (Switcher). View Event displays these details for Fundraising. These are descriptive fields; no payments are processed.
* Heart Hub Events admin screens show a readiness error with setup links until both event-type categories and all three fundraising fields are configured with those exact types.


= 1.13.0 =
* Create/Edit Event supports co_hosted_event (JetEngine Switcher) and presenters (JetEngine Textarea). The switch saves true/false strings and defaults off; presenters preserves multiple lines.
* View Event displays co-hosting status and presenters. Add these exact meta fields to the Events JetEngine configuration; use them in public templates as required.


= 1.12.0 =
* Clicking an event row opens View Event. Keyboard Enter/Space is supported, and embedded action links keep their own behavior.
* Open registration on View Event now opens the existing registration review/edit dialog in place. Saving details or decisions refreshes the event overview without navigating to Registrations.
* Analytics filters now live in a dedicated responsive card below the heading, with separate labels and actions. Export stays beside the heading.


= 1.11.1 =
* Event and category action buttons wrap inside their table cells instead of overflowing or being clipped.

= 1.11.0 =
* Check-in now first looks up the approved registration by email within the current event, then offers all reserved guests or a smaller attending party. Confirmation rechecks the email and reserved count. Lookup alone does not mark attendance.
* Settings > Feedback at check-in controls optional ratings/comments, off by default. Disabled feedback is ignored on the server as well as hidden from guests.
* The preview notice remains admin-only and preview submissions are disabled. Live check-in pages contain no preview notice.
* Events now has separate View Event (plugin overview) and View Page (public page) actions. The overview brings together event details, every registration status, attendance/headcounts, and all event-linked ratings, comments, and suggestions.
* Feedback & Analytics can show all events, one event, preset periods, or a custom inclusive event-date range in the site timezone. Custom dates override the period preset. Rating-only responses are included and comments are no longer limited to eight.
* Post-event thank-you/feedback email automation is retained. Configure its enabled flag/delay and Send real email mode in Settings. It is checked hourly, targets attended/partial registrations without feedback, and uses the existing event-specific, expiring feedback page.
* Data remains on existing event-linked registration records; no duplicate event data store or database migration is introduced. Unrecorded attendance remains separate from confirmed no-shows.




= 1.10.1 =

* Application search now matches name, email, or phone number, including partial numbers and numbers with spaces, brackets, or hyphens.



= 1.10.0 =

* Decline reasons are optional for single and bulk decisions. Blank reasons use: “We’re sorry, we’re unable to approve your registration for this event.”

* Open a registration and expand Edit applicant details to update name, email, phone, organisation, reason for attending, and party size. Save details before reviewing. Admin edits retain the current decision status and do not send a decision email.

* Missing, zero, or negative whole-number party sizes are normalised to one during registration, editing, and review. Lists show at least one. Fractions, nonnumeric values, and sizes above 1,000 are rejected.

* Reserved party-size changes adjust remaining capacity, prevent overbooking, and restore capacity if saving fails. Waitlisted and declined records without reservations do not consume places when edited.

* Party size is locked after check-in to preserve attendance capacity adjustments; contact details remain editable.





= 1.9.0 =

* Automatically appends Past Events (event-category slug past-events, expected ID 83) to published and private events once their configured end date/time is reached. Existing categories remain assigned.

* Checks every five minutes using WP-Cron, including existing past events after upgrade. Execution depends on site traffic or a server cron calling WordPress cron.

* Uses the site timezone for local date/time values and supports Unix timestamps. Missing or invalid end times are skipped. The category must already exist; its slug is used as a fallback if its ID differs.

* This is additive: rescheduling an already categorized event does not automatically remove Past Events. Remove that category manually when rescheduling.



= 1.8.0 =

* Added per-email automation enable switches and configurable delivery delays.

* Added shared branding, palette, and principal copy settings for temporary attendee pages.

* Hardened delayed-email jobs, registration gating, capacity rollback, bearer pages, check-in limits, dashboards, and CSV export.



== Important integration notes ==

The existing admin notification is not replaced or duplicated. Configure its review URL to point to `/wp-admin/admin.php?page=heart-hub-event-registrations&registration_id={CCT_ITEM_ID}` using the correct JetFormBuilder item-ID macro for the installed version. The dashboard review endpoint resolves the event and applicant email server-side. Decision email dry runs are stored in the plugin audit table.
