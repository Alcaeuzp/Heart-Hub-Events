(() => {
  'use strict';
  document.addEventListener('click', event => {
    const button = event.target.closest('[data-hherm-media]');
    if (!button || !window.wp || !wp.media) return;
    event.preventDefault();
    const target = document.getElementById(button.dataset.target);
    if (!target) return;
    const frame = wp.media({ title: 'Choose image', button: { text: 'Use this image' }, multiple: false, library: { type: 'image' } });
    frame.on('select', () => {
      const attachment = frame.state().get('selection').first().toJSON();
      if (attachment && attachment.url) target.value = attachment.url;
    });
    frame.open();
  });
})();
