<?php
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedNamespaceFound -- HeartHub is the established plugin vendor prefix; retain existing class names for integrations.
namespace HeartHub\EventRegistrations;

defined( 'ABSPATH' ) || exit;

/**
 * Manages six-session online support-group programmes.
 */
final class Support_Groups {
	public const PAGE_SLUG = 'hherm-support-groups';
	public const OPTION_PROGRAMMES = 'hherm_support_group_programmes';
	public const OPTION_SETTINGS = 'hherm_support_group_settings';

	public function register(): void {
		add_shortcode( 'hherm_support_groups', array( $this, 'schedule_shortcode' ) );
		add_shortcode( 'hherm_support_group_registration_open', array( $this, 'registration_open_shortcode' ) );
		add_action( 'jet-form-builder/form-handler/before-send', array( $this, 'validate_jetform_submission' ) );
		add_action( 'admin_post_hherm_save_support_group_programme', array( $this, 'save_programme' ) );
		add_action( 'admin_post_hherm_delete_support_group_programme', array( $this, 'delete_programme' ) );
		add_action( 'admin_post_hherm_select_support_group_programme', array( $this, 'select_programme' ) );
	}

	public function settings(): array {
		return wp_parse_args(
			(array) get_option( self::OPTION_SETTINGS, array() ),
			array( 'registration_programme_id' => '' )
		);
	}

	public function programmes(): array {
		$stored = get_option( self::OPTION_PROGRAMMES, array() );
		$programmes = array();
		foreach ( is_array( $stored ) ? $stored : array() as $programme ) {
			if ( ! is_array( $programme ) ) {
				continue;
			}
			$sessions = array();
			foreach ( (array) ( $programme['sessions'] ?? array() ) as $session ) {
				$normalised = $this->normalise_session( $session );
				if ( $normalised ) {
					$sessions[] = $normalised;
				}
			}
			usort( $sessions, array( $this, 'compare_sessions' ) );
			if ( ! $sessions ) {
				continue;
			}
			$programmes[] = array(
				'id'       => sanitize_key( (string) ( $programme['id'] ?? '' ) ),
				'name'     => sanitize_text_field( (string) ( $programme['name'] ?? '' ) ),
				'jetform_id' => absint( $programme['jetform_id'] ?? 0 ),
				'sessions' => array_slice( $sessions, 0, 6 ),
			);
		}

		usort(
			$programmes,
			static function ( array $left, array $right ): int {
				return strcmp( $left['sessions'][0]['date'] . ' ' . $left['sessions'][0]['start_time'], $right['sessions'][0]['date'] . ' ' . $right['sessions'][0]['start_time'] );
			}
		);
		return $programmes;
	}

	public function selected_programme( string $requested_id = '' ) {
		$settings = $this->settings();
		$programme_id = sanitize_key( $requested_id ?: (string) $settings['registration_programme_id'] );
		foreach ( $this->programmes() as $programme ) {
			if ( $programme_id && $programme['id'] === $programme_id ) {
				return $programme;
			}
		}
		return null;
	}

	/**
	 * Registration closes at the first session's starting date and time in the
	 * WordPress site timezone. The full programme remains stored afterwards.
	 */
	public function registration_is_open( array $programme ): bool {
		if ( empty( $programme['sessions'][0] ) ) {
			return false;
		}
		$first_session = $programme['sessions'][0];
		$cutoff = $this->date_time( $first_session['date'], $first_session['start_time'] );
		return $cutoff && current_datetime()->getTimestamp() < $cutoff->getTimestamp();
	}

	public function registration_open_shortcode( $attributes = array() ): string {
		$this->prevent_stale_page_cache();
		$attributes = shortcode_atts( array( 'programme_id' => '' ), (array) $attributes, 'hherm_support_group_registration_open' );
		$programme = $this->selected_programme( sanitize_key( (string) $attributes['programme_id'] ) );
		return $programme && $this->registration_is_open( $programme ) ? 'true' : 'false';
	}

	public function validate_jetform_submission( $handler ): void {
		$programme = $this->selected_programme();
		if ( ! $programme || empty( $programme['jetform_id'] ) ) {
			return;
		}
		$submitted_form_id = is_object( $handler ) && isset( $handler->form_id ) ? absint( $handler->form_id ) : 0;
		if ( absint( $programme['jetform_id'] ) !== $submitted_form_id || $this->registration_is_open( $programme ) ) {
			return;
		}

		$message = esc_html( 'Registration for this support group has closed. Please wait for the next programme or contact the organiser.' );
		if ( class_exists( '\\Jet_Form_Builder\\Exceptions\\Action_Exception' ) ) {
			throw new \Jet_Form_Builder\Exceptions\Action_Exception( $message );
		}
		throw new \RuntimeException( $message );
	}

	public function schedule_shortcode( $attributes = array() ): string {
		$this->prevent_stale_page_cache();
		$attributes = shortcode_atts(
			array(
				'programme_id' => '',
				'date_format'  => 'j F',
				'time_format'  => 'g.i a',
				'empty_text'   => '',
			),
			(array) $attributes,
			'hherm_support_groups'
		);
		$programme = $this->selected_programme( sanitize_key( (string) $attributes['programme_id'] ) );
		$today = current_datetime()->format( 'Y-m-d' );
		$sessions = $programme ? array_values(
			array_filter(
				$programme['sessions'],
				static function ( array $session ) use ( $today ): bool {
					return $session['date'] >= $today;
				}
			)
		) : array();
		if ( ! $sessions ) {
			$empty_text = sanitize_text_field( (string) $attributes['empty_text'] );
			return $empty_text ? '<p class="hherm-support-groups-empty">' . esc_html( $empty_text ) . '</p>' : '';
		}

		wp_enqueue_style( 'hherm-support-groups', HHERM_URL . 'assets/support-groups.css', array(), HHERM_VERSION );
		$date_format = sanitize_text_field( (string) $attributes['date_format'] ) ?: 'j F';
		$time_format = sanitize_text_field( (string) $attributes['time_format'] ) ?: 'g.i a';
		$items = array();
		foreach ( $sessions as $session ) {
			$date_time = $this->date_time( $session['date'], $session['start_time'] );
			if ( ! $date_time ) {
				continue;
			}
			$date_label = wp_date( $date_format, $date_time->getTimestamp(), wp_timezone() );
			$start_label = wp_date( $time_format, $date_time->getTimestamp(), wp_timezone() );
			$time_html = '<time datetime="' . esc_attr( $session['date'] . 'T' . $session['start_time'] ) . '">' . esc_html( $start_label ) . '</time>';
			if ( $session['end_time'] ) {
				$end_date_time = $this->date_time( $session['date'], $session['end_time'] );
				if ( $end_date_time ) {
					$end_label = wp_date( $time_format, $end_date_time->getTimestamp(), wp_timezone() );
					$time_html .= ' <span aria-hidden="true">&ndash;</span> <time datetime="' . esc_attr( $session['date'] . 'T' . $session['end_time'] ) . '">' . esc_html( $end_label ) . '</time>';
				}
			}
			$items[] = '<li class="hherm-support-groups__item"><time class="hherm-support-groups__date" datetime="' . esc_attr( $session['date'] ) . '">' . esc_html( $date_label ) . '</time><span class="hherm-support-groups__time">' . $time_html . '</span></li>';
		}

		return $items ? '<ul class="hherm-support-groups">' . implode( '', $items ) . '</ul>' : '';
	}

	public function render(): void {
		if ( ! current_user_can( Plugin::CAPABILITY ) ) {
			wp_die( esc_html( 'You do not have permission to manage support groups.' ) );
		}

		$programmes = $this->programmes();
		$settings = $this->settings();
		$editing = null;
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only edit and notice selection on a capability-protected admin route; changes use dedicated nonces.
		$edit_id = isset( $_GET['edit'] ) ? sanitize_key( wp_unslash( $_GET['edit'] ) ) : '';
		$notice = isset( $_GET['hherm_notice'] ) ? sanitize_key( wp_unslash( $_GET['hherm_notice'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		foreach ( $programmes as $programme ) {
			if ( $edit_id && $programme['id'] === $edit_id ) {
				$editing = $programme;
				break;
			}
		}
		$form_sessions = $editing ? $editing['sessions'] : array_fill( 0, 6, array( 'date' => '', 'start_time' => '', 'end_time' => '' ) );
		$notices = array(
			'saved'           => array( 'success', 'Support group programme saved.' ),
			'deleted'         => array( 'success', 'Support group programme deleted.' ),
			'selected'        => array( 'success', 'This programme now controls the public schedule and registration button.' ),
			'invalid-name'    => array( 'error', 'Enter a name for the support group programme.' ),
			'invalid-session' => array( 'error', 'Enter six valid session dates and start times. Each end time must be later than its start time.' ),
			'duplicate'       => array( 'error', 'Each session must have a different date and start time.' ),
		);
		?>
		<div class="wrap hherm-support-groups-wrap">
			<header class="hherm-page-header"><div><span class="hherm-eyebrow">Heart Hub Events</span><h1>Support Groups</h1><p>Manage each six-month online programme, its public dates, and its registration cutoff.</p></div></header>
			<?php if ( isset( $notices[ $notice ] ) ) : ?><div class="notice notice-<?php echo esc_attr( $notices[ $notice ][0] ); ?> is-dismissible"><p><?php echo esc_html( $notices[ $notice ][1] ); ?></p></div><?php endif; ?>

			<section class="hherm-form-card">
				<div class="hherm-form-card__heading"><div><h2><?php echo esc_html( $editing ? 'Edit programme' : 'Add programme' ); ?></h2><p>Add all six monthly meetings. The first meeting’s start time is automatically used as the registration cutoff.</p></div></div>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="hherm_save_support_group_programme">
					<input type="hidden" name="programme_id" value="<?php echo esc_attr( $editing['id'] ?? '' ); ?>">
					<?php wp_nonce_field( 'hherm_save_support_group_programme' ); ?>
					<div class="hherm-form-grid"><label>Programme name <input type="text" name="programme_name" required value="<?php echo esc_attr( $editing['name'] ?? '' ); ?>" placeholder="e.g. October 2026 Online Support Group"></label><label>JetFormBuilder form ID <input type="number" name="jetform_id" min="0" step="1" value="<?php echo esc_attr( absint( $editing['jetform_id'] ?? 0 ) ); ?>"><small>Optional but recommended. Late submissions to this form will be rejected after meeting one starts.</small></label></div>
					<div class="hherm-support-group-session-editor">
						<div class="hherm-support-group-session-row is-heading"><span>Meeting</span><span>Date</span><span>Start time</span><span>End time <small>(optional)</small></span></div>
						<?php for ( $index = 0; $index < 6; $index++ ) : $session = $form_sessions[ $index ] ?? array( 'date' => '', 'start_time' => '', 'end_time' => '' ); ?>
						<div class="hherm-support-group-session-row"><strong><?php echo esc_html( $index + 1 ); ?></strong><label><span class="hherm-visually-hidden">Meeting <?php echo esc_html( $index + 1 ); ?> date</span><input type="date" name="session_date[]" required value="<?php echo esc_attr( $session['date'] ); ?>"></label><label><span class="hherm-visually-hidden">Meeting <?php echo esc_html( $index + 1 ); ?> start time</span><input type="time" name="session_start_time[]" required value="<?php echo esc_attr( $session['start_time'] ); ?>"></label><label><span class="hherm-visually-hidden">Meeting <?php echo esc_html( $index + 1 ); ?> end time</span><input type="time" name="session_end_time[]" value="<?php echo esc_attr( $session['end_time'] ); ?>"></label></div>
						<?php endfor; ?>
					</div>
					<div class="hherm-support-groups-form-actions"><button type="submit" class="button button-primary"><?php echo esc_html( $editing ? 'Update programme' : 'Add programme' ); ?></button><?php if ( $editing ) : ?><a class="button" href="<?php echo esc_url( $this->page_url() ); ?>">Cancel</a><?php endif; ?></div>
				</form>
			</section>

			<section class="hherm-form-card">
				<div class="hherm-form-card__heading"><div><h2>Front-end shortcodes</h2><p>Select a programme below, then use these in the page builder.</p></div></div>
				<div class="hherm-support-groups-shortcodes"><div><strong>Six meeting dates</strong><code>[hherm_support_groups]</code><p>Past meeting dates are removed automatically.</p></div><div><strong>Registration visibility value</strong><code>[hherm_support_group_registration_open]</code><p>Returns <code>true</code> before meeting one starts and <code>false</code> from its start time onward.</p></div></div>
			</section>

			<section class="hherm-list-card">
				<div class="hherm-card-heading"><h2>Support group programmes</h2><span><?php echo esc_html( count( $programmes ) ); ?> total</span></div>
				<table class="widefat striped"><thead><tr><th>Programme</th><th>First meeting / cutoff</th><th>Registration</th><th>Public schedule</th><th>Actions</th></tr></thead><tbody>
				<?php if ( ! $programmes ) : ?><tr><td class="hherm-empty-cell" colspan="5">No support group programmes have been added yet.</td></tr><?php endif; ?>
				<?php foreach ( $programmes as $programme ) :
					$is_selected = $programme['id'] === sanitize_key( (string) $settings['registration_programme_id'] );
					$is_open = $this->registration_is_open( $programme );
					$edit_url = add_query_arg( array( 'page' => self::PAGE_SLUG, 'edit' => $programme['id'] ), admin_url( 'admin.php' ) );
					$delete_url = wp_nonce_url( add_query_arg( array( 'action' => 'hherm_delete_support_group_programme', 'programme_id' => $programme['id'] ), admin_url( 'admin-post.php' ) ), 'hherm_delete_support_group_programme_' . $programme['id'] );
					$select_url = wp_nonce_url( add_query_arg( array( 'action' => 'hherm_select_support_group_programme', 'programme_id' => $programme['id'] ), admin_url( 'admin-post.php' ) ), 'hherm_select_support_group_programme_' . $programme['id'] );
				?>
				<tr><td><strong><?php echo esc_html( $programme['name'] ); ?></strong><small><?php echo esc_html( count( $programme['sessions'] ) ); ?> meetings</small></td><td><?php echo esc_html( $this->session_admin_label( $programme['sessions'][0] ) ); ?></td><td><span class="hherm-support-group-status <?php echo esc_attr( $is_open ? 'is-upcoming' : 'is-past' ); ?>"><?php echo esc_html( $is_open ? 'Open' : 'Closed' ); ?></span></td><td><?php if ( $is_selected ) : ?><strong class="hherm-selected-programme">In use</strong><?php else : ?><a class="button button-small" href="<?php echo esc_url( $select_url ); ?>">Use this programme</a><?php endif; ?></td><td><a href="<?php echo esc_url( $edit_url ); ?>">Edit</a> &middot; <a class="hherm-delete-link" href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm('Delete this support group programme?');">Delete</a></td></tr>
				<?php endforeach; ?>
				</tbody></table>
			</section>
		</div>
		<?php
	}

	public function save_programme(): void {
		$this->authorise( 'hherm_save_support_group_programme' );
		$id = isset( $_POST['programme_id'] ) ? sanitize_key( wp_unslash( $_POST['programme_id'] ) ) : '';
		$name = isset( $_POST['programme_name'] ) ? sanitize_text_field( wp_unslash( $_POST['programme_name'] ) ) : '';
		$jetform_id = isset( $_POST['jetform_id'] ) ? absint( wp_unslash( $_POST['jetform_id'] ) ) : 0;
		if ( ! $name ) {
			$this->redirect( 'invalid-name' );
		}
		$dates = isset( $_POST['session_date'] ) ? (array) wp_unslash( $_POST['session_date'] ) : array();
		$starts = isset( $_POST['session_start_time'] ) ? (array) wp_unslash( $_POST['session_start_time'] ) : array();
		$ends = isset( $_POST['session_end_time'] ) ? (array) wp_unslash( $_POST['session_end_time'] ) : array();
		$sessions = array();
		$unique = array();
		for ( $index = 0; $index < 6; $index++ ) {
			$session = $this->normalise_session(
				array(
					'date'       => $dates[ $index ] ?? '',
					'start_time' => $starts[ $index ] ?? '',
					'end_time'   => $ends[ $index ] ?? '',
				)
			);
			if ( ! $session || ( $session['end_time'] && $session['end_time'] <= $session['start_time'] ) ) {
				$this->redirect( 'invalid-session' );
			}
			$key = $session['date'] . 'T' . $session['start_time'];
			if ( isset( $unique[ $key ] ) ) {
				$this->redirect( 'duplicate' );
			}
			$unique[ $key ] = true;
			$sessions[] = $session;
		}
		usort( $sessions, array( $this, 'compare_sessions' ) );
		if ( ! $id ) {
			$id = sanitize_key( wp_generate_uuid4() );
		}

		$programmes = $this->programmes();
		$replacement = array( 'id' => $id, 'name' => $name, 'jetform_id' => $jetform_id, 'sessions' => $sessions );
		$updated = false;
		foreach ( $programmes as $index => $programme ) {
			if ( $programme['id'] === $id ) {
				$programmes[ $index ] = $replacement;
				$updated = true;
				break;
			}
		}
		if ( ! $updated ) {
			$programmes[] = $replacement;
		}
		update_option( self::OPTION_PROGRAMMES, array_values( $programmes ), false );

		$settings = $this->settings();
		if ( empty( $settings['registration_programme_id'] ) ) {
			update_option( self::OPTION_SETTINGS, array( 'registration_programme_id' => $id ), false );
		}
		$this->redirect( 'saved' );
	}

	public function delete_programme(): void {
		if ( ! current_user_can( Plugin::CAPABILITY ) ) {
			wp_die( esc_html( 'You do not have permission to manage support groups.' ) );
		}
		$id = isset( $_GET['programme_id'] ) ? sanitize_key( wp_unslash( $_GET['programme_id'] ) ) : '';
		check_admin_referer( 'hherm_delete_support_group_programme_' . $id );
		$programmes = array_values(
			array_filter(
				$this->programmes(),
				static function ( array $programme ) use ( $id ): bool {
					return $programme['id'] !== $id;
				}
			)
		);
		update_option( self::OPTION_PROGRAMMES, $programmes, false );
		$settings = $this->settings();
		if ( $id === sanitize_key( (string) $settings['registration_programme_id'] ) ) {
			update_option( self::OPTION_SETTINGS, array( 'registration_programme_id' => '' ), false );
		}
		$this->redirect( 'deleted' );
	}

	public function select_programme(): void {
		if ( ! current_user_can( Plugin::CAPABILITY ) ) {
			wp_die( esc_html( 'You do not have permission to manage support groups.' ) );
		}
		$id = isset( $_GET['programme_id'] ) ? sanitize_key( wp_unslash( $_GET['programme_id'] ) ) : '';
		check_admin_referer( 'hherm_select_support_group_programme_' . $id );
		if ( $this->selected_programme( $id ) ) {
			update_option( self::OPTION_SETTINGS, array( 'registration_programme_id' => $id ), false );
		}
		$this->redirect( 'selected' );
	}

	private function normalise_session( $session ) {
		if ( ! is_array( $session ) ) {
			return null;
		}
		$date = $this->normalise_date( $session['date'] ?? '' );
		$start = $this->normalise_time( $session['start_time'] ?? '' );
		$end_raw = trim( (string) ( $session['end_time'] ?? '' ) );
		$end = '' === $end_raw ? '' : $this->normalise_time( $end_raw );
		if ( ! $date || ! $start || ( '' !== $end_raw && ! $end ) ) {
			return null;
		}
		return array( 'date' => $date, 'start_time' => $start, 'end_time' => $end );
	}

	private function prevent_stale_page_cache(): void {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
	}

	private function compare_sessions( array $left, array $right ): int {
		return strcmp( $left['date'] . ' ' . $left['start_time'], $right['date'] . ' ' . $right['start_time'] );
	}

	private function session_admin_label( array $session ): string {
		$date_time = $this->date_time( $session['date'], $session['start_time'] );
		return $date_time ? wp_date( (string) get_option( 'date_format', 'F j, Y' ) . ' ' . (string) get_option( 'time_format', 'g:i a' ), $date_time->getTimestamp(), wp_timezone() ) : '';
	}

	private function date_time( string $date, string $time ) {
		try {
			return new \DateTimeImmutable( $date . ' ' . $time, wp_timezone() );
		} catch ( \Exception $error ) {
			return null;
		}
	}

	private function normalise_date( $value ): string {
		$value = sanitize_text_field( (string) $value );
		$date = \DateTimeImmutable::createFromFormat( '!Y-m-d', $value, wp_timezone() );
		$errors = \DateTimeImmutable::getLastErrors();
		return $date && ( false === $errors || ( 0 === $errors['warning_count'] && 0 === $errors['error_count'] ) ) && $date->format( 'Y-m-d' ) === $value ? $value : '';
	}

	private function normalise_time( $value ): string {
		$value = sanitize_text_field( (string) $value );
		return preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $value ) ? $value : '';
	}

	private function authorise( string $nonce_action ): void {
		if ( ! current_user_can( Plugin::CAPABILITY ) ) {
			wp_die( esc_html( 'You do not have permission to manage support groups.' ) );
		}
		check_admin_referer( $nonce_action );
	}

	private function redirect( string $notice ): void {
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE_SLUG, 'hherm_notice' => sanitize_key( $notice ) ), admin_url( 'admin.php' ) ) );
		exit;
	}

	private function page_url(): string {
		return add_query_arg( array( 'page' => self::PAGE_SLUG ), admin_url( 'admin.php' ) );
	}
}
