<?php
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedNamespaceFound -- HeartHub is the established plugin vendor prefix; retain existing class names for integrations.
namespace HeartHub\EventRegistrations;

defined( 'ABSPATH' ) || exit;

final class JetForm_Integration {
	private $repository; private $settings; private $audit; private $capacity; private $email; private $capacity_lock = array();
	public function __construct( CCT_Repository $repository, Settings $settings, Audit_Log $audit, Capacity_Manager $capacity, $email = null ) { $this->repository = $repository; $this->settings = $settings; $this->audit = $audit; $this->capacity = $capacity; $this->email = $email; }
	public function register(): void {
		add_action( 'jet-form-builder/custom-action/heart_hub_registration_created', array( $this, 'normalise_request' ), 10, 2 );
		add_action( 'jet-form-builder/custom-action/heart_hub_interest_created', array( $this, 'normalise_interest_request' ), 10, 2 );
		add_action( 'jet-engine/custom-content-types/created-item/' . sanitize_key( $this->settings->get( 'cct_slug', 'event_registrations' ) ), array( $this, 'after_created' ), 10, 3 );
	}
	public function normalise_interest_request( $request, $handler ): void {
		$event_id = absint( $request['event_id'] ?? 0 );
		$post = get_post( $event_id );
		$cpt = $this->settings->get( 'events_cpt' );
		$cancelled = in_array( strtolower( (string) get_post_meta( $event_id, 'event_cancelled', true ) ), array( '1', 'true', 'yes', 'on' ), true );
		$schedule_status = sanitize_key( (string) get_post_meta( $event_id, 'event_schedule_status', true ) );
		if ( ! $schedule_status ) $schedule_status = get_post_meta( $event_id, $this->settings->get( 'event_start', 'start_date' ), true ) ? 'scheduled' : 'tba';
		$registration_type = Event_Public_Display::normalise_registration_type( get_post_meta( $event_id, 'registration_type', true ) );
		if ( ! $post || ( $cpt && $cpt !== $post->post_type ) || 'publish' !== $post->post_status || $cancelled || 'tba' !== $schedule_status || 'website_registration' !== $registration_type ) {
			$this->form_error( 'Expressions of interest are no longer available for this event.' );
		}
		try {
			if ( function_exists( 'jet_fb_context' ) ) {
				$context = jet_fb_context();
				$context->update_request( $event_id, 'event_id' );
				$context->update_request( get_current_user_id(), 'user_id' );
				$context->update_request( current_time( 'mysql' ), 'registration_date' );
				$context->update_request( 'interest', 'registration_status' );
				$context->update_request( 'expression_of_interest', 'registration_type' );
				$context->update_request( 1, $this->capacity->attendee_key() ?: 'number_of_attendees' );
			}
		} catch ( \Throwable $error ) {
			throw $error;
		}
	}
	public function normalise_request( $request, $handler ): void {
		if ( method_exists( $handler, 'get_form_id' ) && 2774 !== (int) $handler->get_form_id() ) { return; }
		$event_id = absint( $request['event_id'] ?? 0 ); $post = get_post( $event_id ); $cpt = $this->settings->get( 'events_cpt' );
		$cancelled = in_array( strtolower( (string) get_post_meta( $event_id, 'event_cancelled', true ) ), array( '1', 'true', 'yes', 'on' ), true );
		if ( ! $post || ( $cpt && $cpt !== $post->post_type ) || 'publish' !== $post->post_status || $cancelled ) {
			if ( class_exists( '\\Jet_Form_Builder\\Exceptions\\Action_Exception' ) ) { throw new \Jet_Form_Builder\Exceptions\Action_Exception( 'The selected event is unavailable.' ); }
			throw new \RuntimeException( 'The selected event is unavailable.' );
		}
		$enabled = strtolower( trim( (string) get_post_meta( $event_id, 'registration_enabled', true ) ) );
		if ( 'website_registration' !== Event_Public_Display::normalise_registration_type( get_post_meta( $event_id, 'registration_type', true ) ) ) {
			$this->form_error( 'Website registration is not available for this event.' );
		}
		$schedule_status = sanitize_key( (string) get_post_meta( $event_id, 'event_schedule_status', true ) );
		if ( ! $schedule_status ) $schedule_status = get_post_meta( $event_id, $this->settings->get( 'event_start', 'start_date' ), true ) ? 'scheduled' : 'tba';
		if ( 'tba' === $schedule_status ) {
			$this->form_error( 'This event does not have a confirmed date yet. Please use the expression of interest form.' );
		}
		if ( in_array( $enabled, array( '0', 'false', 'no', 'off' ), true ) ) {
			$this->form_error( 'Registrations for this event are closed.' );
		}
		$now = time();
		$opens = $this->datetime_timestamp( get_post_meta( $event_id, 'registration_open', true ) );
		$closes = $this->datetime_timestamp( get_post_meta( $event_id, 'registration_close', true ) );
		if ( ( $opens && $now < $opens ) || ( $closes && $now >= $closes ) ) {
			$this->form_error( 'Registrations for this event are not currently open.' );
		}
		if ( $this->capacity->partially_configured() ) { $this->form_error( 'Event capacity is not fully configured. Please contact the site administrator.' ); }
		$attendees = $this->capacity->attendees_from( (array) $request );
		if ( is_wp_error( $attendees ) ) { $this->form_error( $attendees->get_error_message() ); }
		$registration_status = 'pending';
		if ( $this->capacity->enabled() ) {
			$attendees = $this->capacity->attendees_from( (array) $request );
			if ( is_wp_error( $attendees ) ) { $this->form_error( $attendees->get_error_message() ); }
			$locked = $this->capacity->lock_for_registration( $event_id, $attendees );
			if ( is_wp_error( $locked ) ) {
				if ( 'hherm_event_at_capacity' === $locked->get_error_code() && $this->waitlist_enabled( $event_id ) ) {
					$registration_status = 'waitlist';
				} else {
					$this->form_error( $locked->get_error_message() );
				}
			} else {
				$this->capacity_lock = array( 'event_id' => $event_id, 'attendees' => $attendees );
			}
		}
		try {
			if ( function_exists( 'jet_fb_context' ) ) { $context = jet_fb_context(); $context->update_request( $event_id, 'event_id' ); $context->update_request( get_current_user_id(), 'user_id' ); $context->update_request( current_time( 'mysql' ), 'registration_date' ); $context->update_request( $registration_status, 'registration_status' ); $context->update_request( $attendees, $this->capacity->attendee_key() ?: 'number_of_attendees' ); }
		} catch ( \Throwable $error ) {
			$this->capacity->abandon_registration( $event_id );
			$this->capacity_lock = array();
			throw $error;
		}
	}
	public function after_created( $item, $item_id, $handler ): void {
		$event_id = absint( is_array( $item ) ? ( $item['event_id'] ?? 0 ) : ( $item->event_id ?? 0 ) );
		if ( $event_id && $item_id ) {
			$registration_id = absint( $item_id );
			$item_array = is_object( $item ) ? get_object_vars( $item ) : (array) $item;
			$item_array['_ID'] = $registration_id;
			$item_array['event_id'] = $event_id;
			$is_interest = 'interest' === sanitize_key( $item_array['registration_status'] ?? '' ) || 'expression_of_interest' === sanitize_key( $item_array['registration_type'] ?? '' );
			$party_key = $this->capacity->attendee_key() ?: 'number_of_attendees';
			$party = $this->capacity->attendees_from( $item_array );
			if ( ! is_wp_error( $party ) && (string) ( $item_array[ $party_key ] ?? '' ) !== (string) $party ) {
				$normalised = $this->repository->update_registration( $registration_id, array( $party_key => $party ) );
				if ( is_wp_error( $normalised ) ) $this->audit->write( $registration_id, 'registration_error', 'party_normalisation_failed', array( 'event_id' => $event_id ) );
				$item_array[ $party_key ] = $party;
			}
			if ( $this->capacity->enabled() && ! $is_interest ) {
				$attendees = $this->capacity->attendees_from( $item_array );
				if ( is_wp_error( $attendees ) ) {
					$this->capacity->abandon_registration( $event_id );
					$this->capacity_lock = array();
					$this->audit->write( $registration_id, 'capacity_error', 'invalid_attendees', array( 'event_id' => $event_id ) );
					return;
				}
				$status = sanitize_key( $item_array['registration_status'] ?? 'pending' );
				if ( 'waitlist' === $status ) {
					if ( $this->capacity_lock ) { $this->capacity->abandon_registration( (int) $this->capacity_lock['event_id'] ); $this->capacity_lock = array(); }
					$result = true;
					$this->audit->write( $registration_id, 'capacity_waitlist', 'waitlist', array( 'event_id' => $event_id, 'attendees' => $attendees ) );
				} elseif ( $this->capacity_lock && $event_id === (int) $this->capacity_lock['event_id'] ) {
					$result = $this->capacity->complete_registration( $registration_id, $event_id, $attendees );
					$this->capacity_lock = array();
				} else {
					$result = $this->capacity->ensure_reserved( $registration_id, $event_id, $attendees );
				}
				if ( is_wp_error( $result ) ) { $this->audit->write( $registration_id, 'capacity_error', $result->get_error_code(), array( 'event_id' => $event_id, 'attendees' => $attendees ) ); }
			}
			$connected = $this->repository->connect_relation( $event_id, $registration_id );
			$this->audit->write( $registration_id, 'relation', $connected ? 'connected' : 'not_configured', array( 'event_id' => $event_id ) );
			if ( $this->email && 'waitlist' === sanitize_key( $item_array['registration_status'] ?? '' ) ) {
				$this->email->send_waitlist( $item_array, $this->email_event( $event_id ) );
			}
		} elseif ( $this->capacity_lock ) {
			$this->capacity->abandon_registration( (int) $this->capacity_lock['event_id'] );
			$this->capacity_lock = array();
		}
	}
	private function waitlist_enabled( int $event_id ): bool { return in_array( strtolower( (string) get_post_meta( $event_id, 'allow_waitlist', true ) ), array( '1', 'true', 'yes', 'on' ), true ); }
	private function datetime_timestamp( $value ): int { $value = trim( (string) $value ); if ( ! $value ) return 0; $date = \DateTimeImmutable::createFromFormat( 'Y-m-d\\TH:i', $value, wp_timezone() ); return $date ? $date->getTimestamp() : 0; }
	private function email_event( int $event_id ): array { $post = get_post( $event_id ); $start = (string) get_post_meta( $event_id, $this->settings->get( 'event_start', 'start_date' ), true ); $end = (string) get_post_meta( $event_id, $this->settings->get( 'event_end', 'end_date__time' ), true ); $name = (string) get_post_meta( $event_id, 'event_name', true ); $info = (string) get_post_meta( $event_id, $this->settings->get( 'event_info', '_description' ), true ); return array( 'id' => $event_id, 'title' => $name ?: get_the_title( $event_id ), 'date' => $this->format_datetime( $start, get_option( 'date_format' ) ), 'start' => $this->format_datetime( $start, get_option( 'time_format' ) ), 'end' => $this->format_datetime( $end, get_option( 'time_format' ) ), 'venue' => (string) get_post_meta( $event_id, $this->settings->get( 'event_venue', 'venue' ), true ), 'organiser' => (string) get_post_meta( $event_id, $this->settings->get( 'event_organiser', 'organiser' ), true ), 'info' => $info ?: ( $post ? $post->post_content : '' ) ); }
	private function format_datetime( string $value, string $format ): string { if ( '' === $value ) return ''; $date = \DateTimeImmutable::createFromFormat( 'Y-m-d\\TH:i', $value, wp_timezone() ); return $date ? wp_date( $format, $date->getTimestamp(), wp_timezone() ) : $value; }
	private function form_error( string $message ): void {
		if ( class_exists( '\Jet_Form_Builder\Exceptions\Action_Exception' ) ) {
			throw new \Jet_Form_Builder\Exceptions\Action_Exception( esc_html( $message ) );
		}
		throw new \RuntimeException( esc_html( $message ) );
	}
}
