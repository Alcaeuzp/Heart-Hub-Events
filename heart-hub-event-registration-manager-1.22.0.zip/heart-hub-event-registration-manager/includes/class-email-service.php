<?php
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedNamespaceFound -- HeartHub is the established plugin vendor prefix; retain existing class names for integrations.
namespace HeartHub\EventRegistrations;

defined( 'ABSPATH' ) || exit;

final class Email_Service {
	private $settings;
	private $audit;
	private $self_service;

	public function __construct( Settings $settings, Audit_Log $audit, ?Registration_Self_Service $self_service = null ) {
		$this->settings      = $settings;
		$this->audit         = $audit;
		$this->self_service = $self_service;
	}

	public function send_decision( array $item, array $event, string $status ): array {
		return $this->send( $item, $event, $status, 'decision_email' );
	}

	public function send_waitlist( array $item, array $event ): array {
		return $this->send( $item, $event, 'waitlist', 'waitlist_email' );
	}

	public function send_cancellation( array $item, array $event ): array {
		$id = absint( $item['_ID'] ?? 0 );
		if ( $this->audit->has_status( $id, 'cancellation_email', 'sent' ) ) {
			return array( 'status' => 'skipped' );
		}
		return $this->send( $item, $event, 'cancelled', 'cancellation_email' );
	}

	public function send_feedback_request( array $item, array $event ): array {
		$id = absint( $item['_ID'] ?? 0 );
		if ( ! $this->settings->automation_enabled( 'feedback' ) || $this->audit->has_status( $id, 'feedback_email', 'sent' ) || $this->audit->has_status( $id, 'feedback_email', 'logged' ) ) {
			return array( 'status' => 'skipped' );
		}
		return $this->send( $item, $event, 'feedback', 'feedback_email' );
	}

	public function send_schedule_confirmed( array $item, array $event ): array {
		return $this->send( $item, $event, 'scheduled', 'schedule_confirmation_email' );
	}

	private function send( array $item, array $event, string $status, string $audit_type ): array {
		$id = absint( $item['_ID'] ?? 0 );
		$to = sanitize_email( $item['email'] ?? '' );
		if ( ! is_email( $to ) ) {
			$this->audit->write( $id, $audit_type, 'failed', array( 'reason' => 'Invalid recipient', 'event_id' => absint( $event['id'] ?? 0 ) ) );
			return array( 'status' => 'failed', 'retryable' => false );
		}

		$subject = $this->subject( $item, $event, $status );
		$body = $this->render( $item, $event, $status );
		$from_name = sanitize_text_field( $this->settings->email( 'brand_name', 'Heart Hub South West' ) );
		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . $from_name . ' <' . sanitize_email( get_option( 'admin_email' ) ) . '>',
		);

		if ( 'send' !== $this->settings->get( 'email_mode', 'log' ) ) {
			$this->audit->write( $id, $audit_type, 'logged', array( 'to' => $to, 'subject' => $subject, 'html' => $body, 'event_id' => absint( $event['id'] ?? 0 ) ) );
			return array( 'status' => 'logged' );
		}

		$sent = wp_mail( $to, $subject, $body, $headers );
		$this->audit->write( $id, $audit_type, $sent ? 'sent' : 'failed', array( 'to' => $to, 'subject' => $subject, 'event_id' => absint( $event['id'] ?? 0 ) ) );
		return array( 'status' => $sent ? 'sent' : 'failed', 'retryable' => ! $sent );
	}

	public function preview( string $status ): string {
		return $this->render( $this->preview_item(), $this->preview_event(), $status, true );
	}

	public function preview_subject( string $status ): string {
		return $this->subject( $this->preview_item(), $this->preview_event(), $status );
	}

	private function preview_item(): array {
		return array(
			'_ID'           => 123,
			'first_name'    => 'Alex',
			'last_name'     => 'Taylor',
			'email'         => 'alex@example.com',
			'number_of_attendees' => 2,
			'decline_reason' => 'Places for this session are currently full.',
			'feedback_url'   => home_url( '/?hherm_feedback=123&hherm_feedback_token=preview' ),
		);
	}

	private function preview_event(): array {
		return array(
			'id'        => 456,
			'title'     => 'Heart Hub Community Workshop',
			'url'       => home_url( '/events/heart-hub-community-workshop/' ),
			'date'      => '24 September 2026',
			'start'     => '10:00 am',
			'end'       => '1:00 pm',
			'venue'     => 'Heart Hub South West',
			'organiser' => 'Heart Hub Team',
			'info'      => 'Please arrive ten minutes before the session begins.',
		);
	}

	public function event_context( int $event_id ): array {
		$post = get_post( $event_id );
		if ( ! $post || 'trash' === $post->post_status || $this->settings->get( 'events_cpt', 'events' ) !== $post->post_type ) return array();
		$start_raw = (string) get_post_meta( $event_id, $this->settings->get( 'event_start', 'start_date' ), true );
		$end_raw = (string) get_post_meta( $event_id, $this->settings->get( 'event_end', 'end_date__time' ), true );
		$date_key = sanitize_key( $this->settings->get( 'event_date', '' ) );
		$date_raw = $date_key ? get_post_meta( $event_id, $date_key, true ) : '';
		$start = $this->parse_event_datetime( $start_raw );
		$end = $this->parse_event_datetime( $end_raw );
		$date = $this->parse_event_datetime( $date_raw );
		if ( ! $date ) $date = $start;
		$date_status = Event_Public_Display::normalise_date_status( get_post_meta( $event_id, 'event_date_status', true ), get_post_meta( $event_id, 'event_schedule_status', true ) );
		$title = (string) get_post_meta( $event_id, 'event_name', true );
		$info = (string) get_post_meta( $event_id, $this->settings->get( 'event_info', '_description' ), true );
		return array(
			'id'        => $event_id,
			'title'     => $title ?: get_the_title( $event_id ),
			'url'       => get_permalink( $event_id ),
			'date'      => 'tbc' === $date_status ? 'Date TBC' : ( $date ? wp_date( get_option( 'date_format' ), $date->getTimestamp(), wp_timezone() ) : '' ),
			'start'     => $start ? wp_date( get_option( 'time_format' ), $start->getTimestamp(), wp_timezone() ) : '',
			'end'       => $end ? wp_date( get_option( 'time_format' ), $end->getTimestamp(), wp_timezone() ) : '',
			'venue'     => (string) get_post_meta( $event_id, $this->settings->get( 'event_venue', 'venue' ), true ),
			'organiser' => (string) get_post_meta( $event_id, $this->settings->get( 'event_organiser', 'organiser' ), true ),
			'info'      => $info ?: (string) $post->post_content,
			'schedule_status' => sanitize_key( (string) get_post_meta( $event_id, 'event_schedule_status', true ) ),
			'expected_month'  => (string) get_post_meta( $event_id, 'expected_month', true ),
		);
	}

	private function parse_event_datetime( $value ) {
		if ( is_numeric( $value ) ) {
			$timestamp = absint( $value );
			return $timestamp ? ( new \DateTimeImmutable( '@' . $timestamp ) )->setTimezone( wp_timezone() ) : false;
		}
		$value = trim( (string) $value );
		if ( '' === $value ) return false;
		foreach ( array( 'Y-m-d\\TH:i:s', 'Y-m-d\\TH:i', 'Y-m-d H:i:s', 'Y-m-d' ) as $format ) {
			$date = \DateTimeImmutable::createFromFormat( '!' . $format, $value, wp_timezone() );
			if ( $date ) return $date;
		}
		return false;
	}

	private function subject( array $item, array $event, string $status ): string {
		$key = 'approved' === $status ? 'approval_subject' : ( 'scheduled' === $status ? 'schedule_confirmation_subject' : ( 'cancelled' === $status ? 'cancellation_subject' : ( 'waitlist' === $status ? 'waitlist_subject' : ( 'feedback' === $status ? 'feedback_subject' : 'decline_subject' ) ) ) );
		$template = (string) $this->settings->email( $key );
		return sanitize_text_field( wp_strip_all_tags( strtr( $template, $this->plain_tokens( $item, $event ) ) ) );
	}

	private function render( array $item, array $event, string $status, bool $preview = false ): string {
		$key = 'approved' === $status ? 'approval_body' : ( 'scheduled' === $status ? 'schedule_confirmation_body' : ( 'cancelled' === $status ? 'cancellation_body' : ( 'waitlist' === $status ? 'waitlist_body' : ( 'feedback' === $status ? 'feedback_body' : 'decline_body' ) ) ) );
		$template = (string) $this->settings->email( $key );
		$tokens = $this->tokens( $item, $event );
		$manage_button = '';
		if ( 'approved' === $status && $this->self_service ) {
			$manage_url = $preview ? home_url( '/?hherm_manage_registration=123&hherm_manage_token=preview' ) : $this->self_service->manage_url( $item, $event );
			$tokens['{manage_registration_url}']    = esc_url( $manage_url );
			$tokens['{manage_registration_button}'] = $this->manage_button( $manage_url );
			$manage_button = $tokens['{manage_registration_button}'];
		}
		if ( 'feedback' === $status ) {
			$feedback_url = esc_url( $item['feedback_url'] ?? home_url( '/' ) );
			$tokens['{feedback_url}'] = $feedback_url;
			$button_colour = sanitize_hex_color( $this->settings->email( 'primary_color' ) ) ?: '#4f87ad';
			$tokens['{feedback_button}'] = '<p style="margin:26px 0"><a href="' . $feedback_url . '" style="display:inline-block;background:' . esc_attr( $button_colour ) . ';color:#fff;text-decoration:none;border-radius:7px;padding:12px 18px;font-weight:bold">Share your feedback</a></p>';
		}
		$content = wp_kses_post( strtr( $template, $tokens ) );
		if ( 'approved' === $status && $manage_button && false === strpos( $template, '{manage_registration_button}' ) ) {
			$content .= $manage_button;
		}
		$brand = esc_html( $this->settings->email( 'brand_name', 'Heart Hub South West' ) );
		$logo_url = esc_url( $this->settings->email( 'logo_url' ) );
		$icon_url = esc_url( $this->settings->email( 'icon_url' ) );
		$primary = sanitize_hex_color( $this->settings->email( 'primary_color' ) ) ?: '#7c3151';
		$background = sanitize_hex_color( $this->settings->email( 'background_color' ) ) ?: '#f4f1ec';
		$text = sanitize_hex_color( $this->settings->email( 'text_color' ) ) ?: '#292929';
		$logo = $logo_url ? '<img src="' . $logo_url . '" alt="' . $brand . '" style="display:block;max-width:220px;max-height:80px;margin:0 0 12px">' : '';
		$icon = $icon_url ? '<img src="' . $icon_url . '" alt="" width="52" height="52" style="display:block;width:52px;height:52px;object-fit:contain;border-radius:10px">' : '';
		$heading = $logo . '<h1 style="margin:0;font-size:24px;color:#fff">' . $brand . '</h1>';
		$header = $icon ? '<table role="presentation" style="border-collapse:collapse;width:100%"><tr><td style="width:66px;padding:0 14px 0 0;vertical-align:middle">' . $icon . '</td><td style="padding:0;vertical-align:middle">' . $heading . '</td></tr></table>' : $heading;

		return '<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body style="margin:0;background:' . esc_attr( $background ) . ';font-family:Arial,sans-serif;color:' . esc_attr( $text ) . '"><div style="max-width:640px;margin:0 auto;padding:28px"><div style="background:' . esc_attr( $primary ) . ';color:#fff;padding:22px;border-radius:12px 12px 0 0">' . $header . '</div><div style="background:#fff;padding:26px;border-radius:0 0 12px 12px;line-height:1.55">' . $content . '</div></div></body></html>';
	}

	private function manage_button( string $url ): string {
		if ( ! $url ) {
			return '';
		}
		$button_colour = sanitize_hex_color( $this->settings->email( 'primary_color' ) ) ?: '#4f87ad';
		return '<p style="margin:26px 0 8px"><a href="' . esc_url( $url ) . '" style="display:inline-block;background:' . esc_attr( $button_colour ) . ';color:#fff;text-decoration:none;border-radius:7px;padding:12px 18px;font-weight:bold">Manage or withdraw your attendance</a></p><p style="margin:0;color:#55707f;font-size:13px">Use this secure link to update your group details or withdraw your place before the event.</p>';
	}

	private function tokens( array $item, array $event ): array {
		$name = trim( (string) ( $item['first_name'] ?? '' ) . ' ' . (string) ( $item['last_name'] ?? '' ) );
		$time = trim( (string) ( $event['start'] ?? '' ) . ( ! empty( $event['end'] ) ? ' – ' . (string) $event['end'] : '' ) );
		$contact = sanitize_email( $this->settings->get( 'contact_email' ) );
		$attendee_key = sanitize_key( $this->settings->get( 'attendee_count_field', 'number_of_attendees' ) );
		$tokens = array(
			'{first_name}'     => esc_html( $item['first_name'] ?? '' ),
			'{applicant_name}' => esc_html( $name ),
			'{event_name}'     => esc_html( $event['title'] ?? '' ),
			'{event_url}'      => esc_url( $event['url'] ?? $this->settings->get( 'events_url' ) ),
			'{event_date}'     => esc_html( $event['date'] ?? '' ),
			'{event_time}'     => esc_html( $time ),
			'{venue}'          => esc_html( $event['venue'] ?? '' ),
			'{organiser}'      => esc_html( $event['organiser'] ?? '' ),
			'{party_size}'     => esc_html( max( 1, absint( $item[ $attendee_key ] ?? $item['number_of_attendees'] ?? $item['attendees'] ?? 1 ) ) ),
			'{event_info}'     => ! empty( $event['info'] ) ? wp_kses_post( wpautop( $event['info'] ) ) : '',
			'{event_details}'  => $this->event_table( $event ),
			'{decline_reason}' => esc_html( $item['decline_reason'] ?? '' ),
			'{events_url}'     => esc_url( $this->settings->get( 'events_url' ) ),
			'{contact_email}'  => $contact,
		);
		$signature_enabled = in_array( strtolower( (string) $this->settings->email( 'signature_enabled', 'true' ) ), array( '1', 'true', 'yes', 'on' ), true );
		$signature = $signature_enabled ? wp_kses_post( strtr( (string) $this->settings->email( 'signature_body', '' ), $tokens ) ) : '';
		$tokens['{signature}'] = $signature;
		$tokens['[email_signature]'] = $signature;
		return $tokens;
	}

	private function plain_tokens( array $item, array $event ): array {
		$plain = array();
		foreach ( $this->tokens( $item, $event ) as $key => $value ) {
			$plain[ $key ] = html_entity_decode( wp_strip_all_tags( (string) $value ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		}
		return $plain;
	}

	private function event_table( array $event ): string {
		$rows = array(
			'Event'     => $event['title'] ?? '',
			'Date'      => $event['date'] ?? '',
			'Time'      => trim( (string) ( $event['start'] ?? '' ) . ( ! empty( $event['end'] ) ? ' – ' . (string) $event['end'] : '' ) ),
			'Venue'     => $event['venue'] ?? '',
			'Organiser' => $event['organiser'] ?? '',
		);
		$html = '<table role="presentation" style="border-collapse:collapse;width:100%;margin:20px 0">';
		foreach ( $rows as $label => $value ) {
			if ( '' !== trim( (string) $value ) ) {
				$html .= '<tr><th style="text-align:left;padding:8px;border-bottom:1px solid #ddd">' . esc_html( $label ) . '</th><td style="padding:8px;border-bottom:1px solid #ddd">' . esc_html( $value ) . '</td></tr>';
			}
		}
		return $html . '</table>' . ( ! empty( $event['info'] ) ? wp_kses_post( wpautop( $event['info'] ) ) : '' );
	}
}
