<?php
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedNamespaceFound -- HeartHub is the established plugin vendor prefix; retain existing class names for integrations.
namespace HeartHub\EventRegistrations;

defined( 'ABSPATH' ) || exit;

final class Email_Page {
	private $settings;
	private $email;

	public function __construct( Settings $settings, Email_Service $email ) {
		$this->settings = $settings;
		$this->email    = $email;
	}

	public function render( bool $embedded = false ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die(
				esc_html__( 'You do not have access to email templates.', 'heart-hub-event-registration-manager' ),
				esc_html__( 'Access denied', 'heart-hub-event-registration-manager' ),
				array( 'response' => 403 )
			);
		}

		$templates = $this->settings->emails();
		$option    = Settings::OPTION_EMAILS;
		?>
		<div class="<?php echo $embedded ? 'hherm-email-editor hherm-settings-email-templates' : 'wrap hherm-email-editor'; ?>">
			<?php if ( $embedded ) : ?><section class="hherm-settings-section hherm-email-template-intro"><div class="hherm-settings-heading"><div><span class="hherm-eyebrow">Content</span><h2><?php echo esc_html__( 'Email templates', 'heart-hub-event-registration-manager' ); ?></h2><p><?php echo esc_html__( 'Choose an email below to jump straight to its editor. Save once to update every template and rendered preview.', 'heart-hub-event-registration-manager' ); ?></p></div></div></section><?php else : ?>
			<h1><?php echo esc_html__( 'Email Templates', 'heart-hub-event-registration-manager' ); ?></h1>
			<p><?php echo esc_html__( 'Choose an email below to jump straight to its editor. Save once to update every template and rendered preview.', 'heart-hub-event-registration-manager' ); ?></p>
			<?php endif; ?>
			<form method="post" action="options.php">
				<?php settings_fields( 'hherm_emails' ); ?>
				<nav class="hherm-email-toolbar" aria-label="Email template sections"><div><a href="#hherm-brand">Brand</a><a href="#hherm-signature">Signature</a><a href="#hherm-approval">Approval</a><a href="#hherm-decline">Decline</a><a href="#hherm-waitlist">Waitlist</a><a href="#hherm-scheduled">Date confirmed</a><a href="#hherm-cancellation">Cancellation</a><a href="#hherm-feedback">Feedback request</a></div><button type="submit" class="button button-primary">Save templates</button></nav>
				<h2 id="hherm-brand"><?php echo esc_html__( 'Brand styling', 'heart-hub-event-registration-manager' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="hherm-brand-name">Brand name</label></th><td><input class="regular-text" id="hherm-brand-name" name="<?php echo esc_attr( $option ); ?>[brand_name]" value="<?php echo esc_attr( $templates['brand_name'] ); ?>"></td></tr>
					<tr><th scope="row"><label for="hherm-logo-url">Logo URL</label></th><td><input class="large-text" type="url" id="hherm-logo-url" name="<?php echo esc_attr( $option ); ?>[logo_url]" value="<?php echo esc_attr( $templates['logo_url'] ); ?>"> <button type="button" class="button" data-hherm-media data-target="hherm-logo-url">Choose logo</button><p class="description">Use an HTTPS image from the WordPress Media Library.</p></td></tr>
					<tr><th scope="row"><label for="hherm-icon-url">Header icon</label></th><td><input class="large-text" type="url" id="hherm-icon-url" name="<?php echo esc_attr( $option ); ?>[icon_url]" value="<?php echo esc_attr( $templates['icon_url'] ); ?>"> <button type="button" class="button" data-hherm-media data-target="hherm-icon-url">Choose icon</button><p class="description">A square icon displayed in the coloured email header.</p></td></tr>
					<tr><th scope="row">Colours</th><td><label>Header <input type="color" name="<?php echo esc_attr( $option ); ?>[primary_color]" value="<?php echo esc_attr( $templates['primary_color'] ); ?>"></label> <label>Background <input type="color" name="<?php echo esc_attr( $option ); ?>[background_color]" value="<?php echo esc_attr( $templates['background_color'] ); ?>"></label> <label>Text <input type="color" name="<?php echo esc_attr( $option ); ?>[text_color]" value="<?php echo esc_attr( $templates['text_color'] ); ?>"></label></td></tr>
				</table>
				<section class="hherm-signature-editor" id="hherm-signature"><h2>Email signature</h2><label><input type="checkbox" name="<?php echo esc_attr( $option ); ?>[signature_enabled]" value="true" <?php checked( 'true', $templates['signature_enabled'] ); ?>> Apply the reusable signature wherever its shortcode appears</label><?php wp_editor( $templates['signature_body'], 'hherm_signature_body', array( 'textarea_name' => $option . '[signature_body]', 'textarea_rows' => 7, 'media_buttons' => false ) ); ?><p class="description">Add <code>[email_signature]</code> or <code>{signature}</code> at the desired position in any email template. The signature can also use <code>{contact_email}</code> and <code>{events_url}</code>.</p></section>
				<p><strong>Available placeholders:</strong> <code>{first_name}</code>, <code>{applicant_name}</code>, <code>{event_name}</code>, <code>{event_url}</code>, <code>{event_date}</code>, <code>{event_time}</code>, <code>{venue}</code>, <code>{organiser}</code>, <code>{party_size}</code>, <code>{event_info}</code>, <code>{event_details}</code>, <code>{decline_reason}</code>, <code>{events_url}</code>, <code>{contact_email}</code>, <code>{manage_registration_url}</code>, <code>{manage_registration_button}</code>, <code>{feedback_url}</code>, <code>{feedback_button}</code>, <code>{signature}</code>, <code>[email_signature]</code>.</p>
				<div class="hherm-template-grid">
					<section id="hherm-approval"><h2>Approval email</h2><label for="hherm-approval-subject"><strong>Subject</strong></label><input class="large-text" id="hherm-approval-subject" name="<?php echo esc_attr( $option ); ?>[approval_subject]" value="<?php echo esc_attr( $templates['approval_subject'] ); ?>"><?php wp_editor( $templates['approval_body'], 'hherm_approval_body', array( 'textarea_name' => $option . '[approval_body]', 'textarea_rows' => 12, 'media_buttons' => false ) ); ?></section>
					<section id="hherm-decline"><h2>Decline email</h2><label for="hherm-decline-subject"><strong>Subject</strong></label><input class="large-text" id="hherm-decline-subject" name="<?php echo esc_attr( $option ); ?>[decline_subject]" value="<?php echo esc_attr( $templates['decline_subject'] ); ?>"><?php wp_editor( $templates['decline_body'], 'hherm_decline_body', array( 'textarea_name' => $option . '[decline_body]', 'textarea_rows' => 12, 'media_buttons' => false ) ); ?></section>
					<section id="hherm-waitlist"><h2>Waitlist email</h2><label for="hherm-waitlist-subject"><strong>Subject</strong></label><input class="large-text" id="hherm-waitlist-subject" name="<?php echo esc_attr( $option ); ?>[waitlist_subject]" value="<?php echo esc_attr( $templates['waitlist_subject'] ); ?>"><?php wp_editor( $templates['waitlist_body'], 'hherm_waitlist_body', array( 'textarea_name' => $option . '[waitlist_body]', 'textarea_rows' => 12, 'media_buttons' => false ) ); ?></section>
					<section id="hherm-scheduled"><h2>Date confirmed email</h2><p class="description">Sent to expressions of interest when a TBA event is first given a confirmed schedule.</p><label for="hherm-scheduled-subject"><strong>Subject</strong></label><input class="large-text" id="hherm-scheduled-subject" name="<?php echo esc_attr( $option ); ?>[schedule_confirmation_subject]" value="<?php echo esc_attr( $templates['schedule_confirmation_subject'] ); ?>"><?php wp_editor( $templates['schedule_confirmation_body'], 'hherm_schedule_confirmation_body', array( 'textarea_name' => $option . '[schedule_confirmation_body]', 'textarea_rows' => 12, 'media_buttons' => false ) ); ?></section>
					<section id="hherm-cancellation"><h2>Event cancellation email</h2><label for="hherm-cancellation-subject"><strong>Subject</strong></label><input class="large-text" id="hherm-cancellation-subject" name="<?php echo esc_attr( $option ); ?>[cancellation_subject]" value="<?php echo esc_attr( $templates['cancellation_subject'] ); ?>"><?php wp_editor( $templates['cancellation_body'], 'hherm_cancellation_body', array( 'textarea_name' => $option . '[cancellation_body]', 'textarea_rows' => 12, 'media_buttons' => false ) ); ?></section>
					<section id="hherm-feedback"><h2>Post-event feedback request</h2><p class="description">Sent automatically after an attended event when no feedback has been recorded.</p><label for="hherm-feedback-subject"><strong>Subject</strong></label><input class="large-text" id="hherm-feedback-subject" name="<?php echo esc_attr( $option ); ?>[feedback_subject]" value="<?php echo esc_attr( $templates['feedback_subject'] ); ?>"><?php wp_editor( $templates['feedback_body'], 'hherm_feedback_body', array( 'textarea_name' => $option . '[feedback_body]', 'textarea_rows' => 12, 'media_buttons' => false ) ); ?></section>
				</div>
				<?php submit_button( 'Save email templates' ); ?>
			</form>
			<h2><?php echo esc_html__( 'Rendered previews', 'heart-hub-event-registration-manager' ); ?></h2>
			<div class="hherm-preview-grid">
				<section><h3>Approval: <?php echo esc_html( $this->email->preview_subject( 'approved' ) ); ?></h3><iframe sandbox title="Approval email preview" srcdoc="<?php echo esc_attr( $this->email->preview( 'approved' ) ); ?>"></iframe></section>
				<section><h3>Decline: <?php echo esc_html( $this->email->preview_subject( 'declined' ) ); ?></h3><iframe sandbox title="Decline email preview" srcdoc="<?php echo esc_attr( $this->email->preview( 'declined' ) ); ?>"></iframe></section>
				<section><h3>Waitlist: <?php echo esc_html( $this->email->preview_subject( 'waitlist' ) ); ?></h3><iframe sandbox title="Waitlist email preview" srcdoc="<?php echo esc_attr( $this->email->preview( 'waitlist' ) ); ?>"></iframe></section>
				<section><h3>Date confirmed: <?php echo esc_html( $this->email->preview_subject( 'scheduled' ) ); ?></h3><iframe sandbox title="Date confirmed email preview" srcdoc="<?php echo esc_attr( $this->email->preview( 'scheduled' ) ); ?>"></iframe></section>
				<section><h3>Cancellation: <?php echo esc_html( $this->email->preview_subject( 'cancelled' ) ); ?></h3><iframe sandbox title="Event cancellation email preview" srcdoc="<?php echo esc_attr( $this->email->preview( 'cancelled' ) ); ?>"></iframe></section>
				<section><h3>Feedback: <?php echo esc_html( $this->email->preview_subject( 'feedback' ) ); ?></h3><iframe sandbox title="Post-event feedback email preview" srcdoc="<?php echo esc_attr( $this->email->preview( 'feedback' ) ); ?>"></iframe></section>
			</div>
		</div>
		<?php
	}
}
