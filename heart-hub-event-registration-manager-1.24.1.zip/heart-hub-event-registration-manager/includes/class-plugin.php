<?php
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedNamespaceFound -- HeartHub is the established plugin vendor prefix; retain existing class names for integrations.
namespace HeartHub\EventRegistrations;

defined( 'ABSPATH' ) || exit;

final class Plugin {
	public const CAPABILITY = 'manage_heart_hub_event_registrations';
	private static $instance;

	public static function instance(): self {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$settings   = new Settings();
		$audit      = new Audit_Log();
		$repository = new CCT_Repository( $settings );
		$capacity   = new Capacity_Manager( $settings, $audit );
		$public_pages = new Public_Page_Theme( $settings );
		$event_display = new Event_Public_Display( $settings );
		$self_service = new Registration_Self_Service( $settings, $repository, $audit, $capacity, $public_pages );
		$email      = new Email_Service( $settings, $audit, $self_service );
		$support_groups = new Support_Groups( $settings, $email );
		$email_automation = new Email_Automation( $settings, $repository, $audit, $email );
		$feedback   = new Post_Event_Feedback( $settings, $repository, $audit, $email, $public_pages );
		$metrics    = new Event_Metrics( $settings, $repository );
		$events     = new Event_Manager( $settings, $audit, $capacity, $repository, $email_automation, $metrics );
		$checkin    = new Checkin_Manager( $settings, $repository, $audit, $capacity, $public_pages );
		$checkin_page = new Checkin_Page( $settings, $checkin );
		$attendance = new Attendance_Manager( $settings, $repository, $audit, $checkin, $checkin_page );
		$registrations_page = new Registrations_Page();
		$email_page         = new Email_Page( $settings, $email );
		$analytics_page     = new Analytics_Page( $settings, $repository );

		$settings->register();
		$event_display->register();
		$support_groups->register();
		$metrics->register();
		( new Event_Type_Readiness( $settings ) )->register();
		$email_automation->register();
		$self_service->register();
		$events->register();
		( new Past_Events( $settings ) )->register();
		$checkin->register();
		$attendance->register();
		$feedback->register();
		( new Admin_Page( $settings, $registrations_page, $email_page, $events, $attendance, $checkin_page, $analytics_page, $support_groups ) )->register();
		( new REST_Controller( $repository, $email_automation, $audit, $settings, $capacity ) )->register();
		( new JetForm_Integration( $repository, $settings, $audit, $capacity, $email_automation ) )->register();

		add_action( 'admin_notices', array( $this, 'dependency_notice' ) );
		add_action( 'init', array( $this, 'sync_role_capabilities' ), 20 );
	}

	public static function activate(): void {
		Audit_Log::install();
		Support_Groups::install();
		$role = get_role( 'administrator' );
		if ( $role ) {
			$role->add_cap( self::CAPABILITY );
		}
		Post_Event_Feedback::schedule();
	}

	public static function deactivate(): void {
		Past_Events::unschedule();
		Post_Event_Feedback::unschedule();
		Email_Automation::unschedule();
		delete_transient( 'hherm_feedback_cron_lock' );
	}

	public function sync_role_capabilities(): void {
		$roles = (array) get_option( Settings::OPTION_OWNER_ROLES, array() );
		$roles[] = 'administrator';
		foreach ( array_unique( array_map( 'sanitize_key', $roles ) ) as $role_name ) {
			$role = get_role( $role_name );
			if ( $role && ! $role->has_cap( self::CAPABILITY ) ) {
				$role->add_cap( self::CAPABILITY );
			}
		}
	}

	public function dependency_notice(): void {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		$missing = array();
		if ( ! class_exists( '\\Jet_Engine\\Modules\\Custom_Content_Types\\Module' ) ) {
			$missing[] = 'JetEngine Custom Content Types';
		}
		if ( ! function_exists( 'jet_form_builder' ) && ! defined( 'JET_FORM_BUILDER_VERSION' ) ) {
			$missing[] = 'JetFormBuilder';
		}
		if ( $missing ) {
			printf(
				'<div class="notice notice-warning"><p>%s</p></div>',
				esc_html( sprintf( 'Heart Hub Event Registration Manager requires: %s.', implode( ', ', $missing ) ) )
			);
		}
	}
}
