<?php
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedNamespaceFound -- Established plugin namespace.
namespace HeartHub\EventRegistrations;

defined( 'ABSPATH' ) || exit;

/** Token-owned locks shared by registration and capacity mutation entry points. */
final class Mutation_Lock {
	public static function acquire( string $name, int $ttl = 300 ) {
		$token = bin2hex( random_bytes( 16 ) );
		$value = array( 'token' => $token, 'expires_at' => time() + max( 1, $ttl ) );
		for ( $attempt = 0; $attempt < 2; ++$attempt ) {
			if ( add_option( $name, $value, '', false ) ) return $token;
			wp_cache_delete( $name, 'options' );
			$current = get_option( $name, false );
			// Older plugin versions stored the acquisition timestamp alone.
			$expiry = is_array( $current ) ? absint( $current['expires_at'] ?? 0 ) : absint( $current ) + max( 1, $ttl );
			if ( $current && $expiry > time() ) break;
			self::delete_if_unchanged( $name, $current );
		}
		return new \WP_Error( 'hherm_locked', 'This record is being updated. Please try again.', array( 'status' => 409 ) );
	}

	public static function owns( string $name, string $token ): bool {
		wp_cache_delete( $name, 'options' );
		$current = get_option( $name, array() );
		return is_array( $current ) && ! empty( $current['token'] ) && hash_equals( (string) $current['token'], $token ) && absint( $current['expires_at'] ?? 0 ) > time();
	}

	public static function release( string $name, string $token ): void {
		wp_cache_delete( $name, 'options' );
		$current = get_option( $name, array() );
		if ( is_array( $current ) && ! empty( $current['token'] ) && hash_equals( (string) $current['token'], $token ) ) self::delete_if_unchanged( $name, $current );
	}

	private static function delete_if_unchanged( string $name, $expected ): void {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Atomic comparison prevents deleting a replacement owner's lock.
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", $name, maybe_serialize( $expected ) ) );
		wp_cache_delete( $name, 'options' );
	}
}
