(function () {
	'use strict';

	function closeCard(card) {
		var button = card.querySelector('[data-hherm-event-trigger]');
		var popup = button ? document.getElementById(button.getAttribute('aria-controls')) : null;
		if (!button || !popup) return;
		card.classList.remove('is-open');
		button.setAttribute('aria-expanded', 'false');
		popup.hidden = true;
	}

	function openCard(card) {
		var button = card.querySelector('[data-hherm-event-trigger]');
		var popup = button ? document.getElementById(button.getAttribute('aria-controls')) : null;
		if (!button || !popup) return;
		card.classList.add('is-open');
		button.setAttribute('aria-expanded', 'true');
		popup.hidden = false;
	}

	document.addEventListener('mouseover', function (event) {
		var card = event.target.closest('[data-hherm-event-card]');
		if (card && card.closest('[data-popups="1"]')) openCard(card);
	});

	document.addEventListener('mouseout', function (event) {
		var card = event.target.closest('[data-hherm-event-card]');
		if (!card || !card.closest('[data-popups="1"]') || card.contains(event.relatedTarget)) return;
		if (!card.contains(document.activeElement) && !card.classList.contains('is-pinned')) closeCard(card);
	});

	document.addEventListener('focusin', function (event) {
		var card = event.target.closest('[data-hherm-event-card]');
		if (card && card.closest('[data-popups="1"]')) openCard(card);
	});

	document.addEventListener('focusout', function (event) {
		var card = event.target.closest('[data-hherm-event-card]');
		if (!card || card.contains(event.relatedTarget)) return;
		if (!card.classList.contains('is-pinned')) closeCard(card);
	});

	document.addEventListener('click', function (event) {
		var trigger = event.target.closest('[data-hherm-event-trigger]');
		if (trigger) {
			var card = trigger.closest('[data-hherm-event-card]');
			var is_open = 'true' === trigger.getAttribute('aria-expanded');
			document.querySelectorAll('[data-hherm-event-card].is-pinned').forEach(function (open_card) {
				if (open_card !== card) {
					open_card.classList.remove('is-pinned');
					closeCard(open_card);
				}
			});
			if (is_open && card.classList.contains('is-pinned')) {
				card.classList.remove('is-pinned');
				closeCard(card);
			} else {
				card.classList.add('is-pinned');
				openCard(card);
			}
			return;
		}

		if (!event.target.closest('[data-hherm-event-card]')) {
			document.querySelectorAll('[data-hherm-event-card].is-pinned').forEach(function (card) {
				card.classList.remove('is-pinned');
				closeCard(card);
			});
		}
	});

	document.addEventListener('keydown', function (event) {
		if ('Escape' !== event.key) return;
		document.querySelectorAll('[data-hherm-event-card].is-open').forEach(function (card) {
			card.classList.remove('is-pinned');
			closeCard(card);
		});
	});
}());
