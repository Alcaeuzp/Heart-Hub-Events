<?php
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedNamespaceFound -- HeartHub is the established plugin vendor prefix; retain existing class names for integrations.
namespace HeartHub\EventRegistrations;

defined( 'ABSPATH' ) || exit;

/**
 * Calendar display settings shared by the public shortcode and schedule manager.
 */
final class Calendar_Settings {
	public const PAGE_SLUG = 'hherm-calendar-settings';
	public const OPTION = 'hherm_calendar_display';

	private $hook_suffix = '';

	public function register(): void {
		add_action( 'admin_menu', array( $this, 'add_menu' ), 21 );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	public function enqueue_assets( string $hook_suffix ): void {
		if ( $hook_suffix !== $this->hook_suffix ) return;
		wp_enqueue_style( 'hherm-admin-base', HHERM_URL . 'assets/admin-base.css', array(), HHERM_VERSION );
		wp_enqueue_style( 'hherm-events', HHERM_URL . 'assets/events.css', array( 'hherm-admin-base' ), HHERM_VERSION );
		wp_enqueue_style( 'hherm-calendar-schedule', HHERM_URL . 'assets/calendar-schedule.css', array( 'hherm-admin-base' ), HHERM_VERSION );
	}

	public function add_menu(): void {
		$this->hook_suffix = (string) add_submenu_page(
			Admin_Page::MENU_SLUG,
			'Calendar Settings',
			'Calendar Settings',
			Plugin::CAPABILITY,
			self::PAGE_SLUG,
			array( $this, 'render' )
		);
	}

	public function register_settings(): void {
		register_setting( 'hherm_calendar_display', self::OPTION, array( 'sanitize_callback' => array( $this, 'sanitize' ) ) );
		add_filter( 'option_page_capability_hherm_calendar_display', static function (): string { return Plugin::CAPABILITY; } );
	}

	public function sanitize( $input ): array {
		$input = is_array( $input ) ? $input : array();
		$defaults = self::defaults();
		$heading = $input['heading'] ?? $defaults['heading'];
		$week_start = $input['week_start'] ?? '1';
		return array(
			'show_heading'  => empty( $input['show_heading'] ) ? 0 : 1,
			'heading'       => substr( sanitize_text_field( is_scalar( $heading ) ? (string) $heading : $defaults['heading'] ), 0, 120 ),
			'week_start'    => is_scalar( $week_start ) && '0' === (string) $week_start ? 0 : 1,
			'months_behind' => $this->bounded_month_setting( $input['months_behind'] ?? $defaults['months_behind'], 12, true ),
			'months_ahead'  => $this->bounded_month_setting( $input['months_ahead'] ?? $defaults['months_ahead'], 36, false ),
			'show_popups'   => empty( $input['show_popups'] ) ? 0 : 1,
			'show_times'    => empty( $input['show_times'] ) ? 0 : 1,
		);
	}

	public static function defaults(): array {
		return array(
			'show_heading'  => 0,
			'heading'       => 'Events Calendar',
			'week_start'    => 1,
			'months_behind' => 12,
			'months_ahead'  => 36,
			'show_popups'   => 1,
			'show_times'    => 1,
		);
	}

	public static function get(): array {
		$saved = get_option( self::OPTION, array() );
		return array_merge( self::defaults(), is_array( $saved ) ? $saved : array() );
	}

	public function render(): void {
		if ( ! current_user_can( Plugin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to manage calendar settings.', 'heart-hub-event-registration-manager' ), esc_html__( 'Access denied', 'heart-hub-event-registration-manager' ), array( 'response' => 403 ) );
		}
		$settings = self::get();
		?>
		<div class="wrap hherm-events-wrap hherm-calendar-schedule-wrap">
			<header class="hherm-page-header"><div><span class="hherm-eyebrow">Heart Hub Events</span><h1>Calendar Settings</h1><p>Control how the plugin calendar appears on the public Events page.</p></div><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=' . Calendar_Schedule::PAGE_SLUG ) ); ?>">Manage schedules</a></header>
			<?php if ( isset( $_GET['settings-updated'] ) ) : ?><div class="notice notice-success is-dismissible"><p>Calendar settings saved.</p></div><?php endif; ?>
			<div class="notice notice-info inline"><p>Use the shortcode <code>[hherm_events_calendar]</code> in an Elementor Shortcode widget or the WordPress editor. Recurring schedules are calculated for the month being viewed, so they do not create thousands of event posts.</p></div>
			<form method="post" action="options.php" class="hherm-calendar-settings-form">
				<?php settings_fields( 'hherm_calendar_display' ); ?>
				<table class="form-table" role="presentation">
					<tr><th scope="row">Heading</th><td><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[show_heading]" value="1" <?php checked( $settings['show_heading'], 1 ); ?>> Show a heading above the calendar</label><p><input class="regular-text" type="text" name="<?php echo esc_attr( self::OPTION ); ?>[heading]" value="<?php echo esc_attr( $settings['heading'] ); ?>" maxlength="120"></p></td></tr>
					<tr><th scope="row">Week starts on</th><td><select name="<?php echo esc_attr( self::OPTION ); ?>[week_start]"><option value="1" <?php selected( (int) $settings['week_start'], 1 ); ?>>Monday</option><option value="0" <?php selected( (int) $settings['week_start'], 0 ); ?>>Sunday</option></select></td></tr>
					<tr><th scope="row">Months available in the past</th><td><select name="<?php echo esc_attr( self::OPTION ); ?>[months_behind]"><?php $this->month_options( (int) $settings['months_behind'], true ); ?></select><p class="description">This controls how far the calendar can navigate before the current month.</p></td></tr>
					<tr><th scope="row">Months available ahead</th><td><select name="<?php echo esc_attr( self::OPTION ); ?>[months_ahead]"><?php $this->month_options( (int) $settings['months_ahead'], false ); ?></select><p class="description">The default is three years. Recurring dates are calculated as visitors move through the calendar.</p></td></tr>
					<tr><th scope="row">Event details</th><td><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[show_popups]" value="1" <?php checked( $settings['show_popups'], 1 ); ?>> Show event details on hover, keyboard focus, or tap</label></td></tr>
					<tr><th scope="row">Event times</th><td><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[show_times]" value="1" <?php checked( $settings['show_times'], 1 ); ?>> Show event times on calendar entries</label></td></tr>
				</table>
				<?php submit_button( 'Save calendar settings' ); ?>
			</form>
		</div>
		<?php
	}

	private function month_options( int $selected, bool $allow_zero ): void {
		$options = $allow_zero ? array( 0, 3, 6, 12, 24, 36 ) : array( 3, 6, 12, 24, 36 );
		foreach ( $options as $months ) {
			$label = 0 === $months ? 'Current month only' : sprintf( _n( '%d month', '%d months', $months, 'heart-hub-event-registration-manager' ), $months );
			echo '<option value="' . esc_attr( (string) $months ) . '" ' . selected( $selected, $months, false ) . '>' . esc_html( $label ) . '</option>';
		}
	}

	private function bounded_month_setting( $value, int $default, bool $allow_zero ): int {
		$value = is_scalar( $value ) ? absint( $value ) : $default;
		$allowed = $allow_zero ? array( 0, 3, 6, 12, 24, 36 ) : array( 3, 6, 12, 24, 36 );
		return in_array( $value, $allowed, true ) ? $value : $default;
	}
}
