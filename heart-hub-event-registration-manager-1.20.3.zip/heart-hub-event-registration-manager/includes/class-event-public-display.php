<?php
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedNamespaceFound -- HeartHub is the established plugin vendor prefix; retain existing class names for integrations.
namespace HeartHub\EventRegistrations;

defined( 'ABSPATH' ) || exit;

/**
 * Front-end presentation helpers for the existing JetEngine event templates.
 *
 * The live event layouts are owned by JetEngine/Elementor rather than this
 * plugin. These shortcodes provide one authoritative rendering path that those
 * templates can use without duplicating the event option rules.
 */
final class Event_Public_Display {
	private $settings;

	public function __construct( Settings $settings ) {
		$this->settings = $settings;
	}

	public function register(): void {
		add_shortcode( 'hherm_event_date', array( $this, 'date_shortcode' ) );
		add_shortcode( 'hherm_event_registration_cta', array( $this, 'registration_cta_shortcode' ) );
		add_shortcode( 'hherm_event_remaining_spots', array( $this, 'remaining_spots_shortcode' ) );
		add_shortcode( 'hherm_event_what_to_expect', array( $this, 'what_to_expect_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ) );
	}

	public static function normalise_registration_type( $value ): string {
		$value = sanitize_key( (string) $value );
		$aliases = array(
			'website'  => 'website_registration',
			'internal' => 'website_registration',
			'external' => 'external_registration',
			'none'     => 'no_registration',
		);
		$value = $aliases[ $value ] ?? $value;
		return in_array( $value, array( 'website_registration', 'external_registration', 'no_registration' ), true ) ? $value : 'website_registration';
	}

	public static function supports_registration_display_switches( $value ): bool {
		return 'website_registration' === self::normalise_registration_type( $value );
	}

	public static function normalise_date_status( $value, $legacy_value = '' ): string {
		$value = sanitize_key( (string) $value );
		if ( in_array( $value, array( 'confirmed', 'tbc' ), true ) ) return $value;
		$legacy_value = sanitize_key( (string) $legacy_value );
		return 'tba' === $legacy_value ? 'tbc' : 'confirmed';
	}

	public static function normalise_flag( $value, bool $default = true ): bool {
		if ( '' === (string) $value ) return $default;
		return in_array( strtolower( trim( (string) $value ) ), array( '1', 'true', 'yes', 'on' ), true );
	}

	public function registration_type( int $event_id ): string {
		return self::normalise_registration_type( get_post_meta( $event_id, 'registration_type', true ) );
	}

	public function date_status( int $event_id ): string {
		return self::normalise_date_status(
			get_post_meta( $event_id, 'event_date_status', true ),
			get_post_meta( $event_id, 'event_schedule_status', true )
		);
	}

	public function show_register_button( int $event_id ): bool {
		return self::supports_registration_display_switches( $this->registration_type( $event_id ) ) && self::normalise_flag( get_post_meta( $event_id, 'show_register_now_button', true ), true );
	}

	public function show_remaining_spots( int $event_id ): bool {
		return self::supports_registration_display_switches( $this->registration_type( $event_id ) ) && self::normalise_flag( get_post_meta( $event_id, 'show_remaining_spots', true ), true );
	}

	public function show_what_to_expect( int $event_id ): bool {
		return self::normalise_flag( get_post_meta( $event_id, 'show_what_to_expect', true ), true );
	}

	public function enqueue_styles(): void {
		wp_enqueue_style( 'hherm-event-public', HHERM_URL . 'assets/event-public.css', array(), HHERM_VERSION );
	}

	public function date_shortcode( $attributes = array() ): string {
		$attributes = shortcode_atts( array( 'event_id' => 0, 'format' => '' ), (array) $attributes, 'hherm_event_date' );
		$event_id = $this->event_id( $attributes['event_id'] );
		if ( ! $event_id ) return '';
		if ( 'tbc' === $this->date_status( $event_id ) ) return '<span class="hherm-event-date hherm-event-date--tbc">' . esc_html__( 'Date TBC', 'heart-hub-event-registration-manager' ) . '</span>';

		$start_key = sanitize_key( (string) $this->settings->get( 'event_start', 'start_date' ) ) ?: 'start_date';
		$start = (string) get_post_meta( $event_id, $start_key, true );
		if ( '' === $start ) return '';
		$format = sanitize_text_field( (string) $attributes['format'] ) ?: get_option( 'date_format' );
		$timestamp = $this->datetime_timestamp( $start );
		$label = $timestamp ? wp_date( $format, $timestamp, wp_timezone() ) : $start;
		return '<time class="hherm-event-date"' . ( $timestamp ? ' datetime="' . esc_attr( wp_date( 'c', $timestamp, wp_timezone() ) ) . '"' : '' ) . '>' . esc_html( $label ) . '</time>';
	}

	public function registration_cta_shortcode( $attributes = array() ): string {
		$attributes = shortcode_atts(
			array(
				'event_id'      => 0,
				'website_url'   => '#event-registration',
				'website_label' => 'Register Now',
				'external_label'=> 'Register Now',
				'contact_label' => 'Contact Us',
				'class'         => '',
			),
			(array) $attributes,
			'hherm_event_registration_cta'
		);
		$event_id = $this->event_id( $attributes['event_id'] );
		if ( ! $event_id ) return '';
		$type = $this->registration_type( $event_id );
		$url = '';
		$label = '';
		$external = false;

		if ( 'no_registration' === $type ) {
			if ( 'contact_us' !== sanitize_key( (string) get_post_meta( $event_id, 'no_registration_cta', true ) ) ) return '';
			$url = $this->contact_url();
			$label = sanitize_text_field( (string) $attributes['contact_label'] );
		} else {
			if ( ! $this->show_register_button( $event_id ) ) return '';
			if ( 'external_registration' === $type ) {
				$url = esc_url_raw( (string) get_post_meta( $event_id, 'external_registration_url', true ) );
				$label = sanitize_text_field( (string) $attributes['external_label'] );
				$external = true;
			} else {
				$url = (string) apply_filters( 'hherm/website_registration_url', $attributes['website_url'], $event_id );
				$label = sanitize_text_field( (string) $attributes['website_label'] );
			}
		}

		if ( ! $url || ! $label ) return '';
		$classes = trim( 'hherm-event-cta hherm-event-cta--' . str_replace( '_registration', '', $type ) . ' ' . sanitize_html_class( (string) $attributes['class'] ) );
		return '<a class="' . esc_attr( $classes ) . '" href="' . esc_url( $url ) . '"' . ( $external ? ' target="_blank" rel="noopener noreferrer"' : '' ) . '>' . esc_html( $label ) . '</a>';
	}

	public function remaining_spots_shortcode( $attributes = array() ): string {
		$attributes = shortcode_atts( array( 'event_id' => 0, 'singular' => '%d spot remaining', 'plural' => '%d spots remaining' ), (array) $attributes, 'hherm_event_remaining_spots' );
		$event_id = $this->event_id( $attributes['event_id'] );
		if ( ! $event_id || ! $this->show_remaining_spots( $event_id ) ) return '';
		$key = sanitize_key( (string) $this->settings->get( 'event_remaining_capacity', 'current_event_capacity' ) );
		if ( ! $key ) return '';
		$value = get_post_meta( $event_id, $key, true );
		if ( '' === (string) $value ) $value = get_post_meta( $event_id, 'event_capacity', true );
		if ( '' === (string) $value || ! is_numeric( $value ) ) return '';
		$remaining = max( 0, (int) $value );
		$template = 1 === $remaining ? (string) $attributes['singular'] : (string) $attributes['plural'];
		return '<span class="hherm-event-remaining-spots">' . esc_html( sprintf( $template, $remaining ) ) . '</span>';
	}

	public function what_to_expect_shortcode( $attributes = array() ): string {
		$attributes = shortcode_atts( array( 'event_id' => 0, 'heading' => 'What to Expect' ), (array) $attributes, 'hherm_event_what_to_expect' );
		$event_id = $this->event_id( $attributes['event_id'] );
		if ( ! $event_id || ! $this->show_what_to_expect( $event_id ) ) return '';
		$items = get_post_meta( $event_id, 'what_to_expect', true );
		if ( is_string( $items ) && '' !== $items ) $items = json_decode( $items, true );
		if ( ! is_array( $items ) || ! $items ) return '';
		$html = '<section class="hherm-event-expectations"><h2>' . esc_html( sanitize_text_field( (string) $attributes['heading'] ) ) . '</h2><ol>';
		$count = 0;
		foreach ( array_slice( $items, 0, 6 ) as $item ) {
			if ( ! is_array( $item ) ) continue;
			$title = sanitize_text_field( (string) ( $item['title'] ?? '' ) );
			$content = sanitize_textarea_field( (string) ( $item['content'] ?? '' ) );
			if ( '' === $title && '' === $content ) continue;
			$html .= '<li><strong>' . esc_html( $title ) . '</strong><span>' . nl2br( esc_html( $content ) ) . '</span></li>';
			++$count;
		}
		$html .= '</ol></section>';
		return $count ? $html : '';
	}

	private function event_id( $value ): int {
		$event_id = absint( $value );
		return $event_id ?: absint( get_the_ID() );
	}

	private function contact_url(): string {
		$page = get_page_by_path( 'contact-us' );
		$url = $page ? get_permalink( $page ) : home_url( '/contact-us/' );
		return esc_url_raw( (string) apply_filters( 'hherm/contact_url', $url ) );
	}

	private function datetime_timestamp( string $value ): int {
		if ( is_numeric( $value ) ) return (int) $value;
		$date = \DateTimeImmutable::createFromFormat( 'Y-m-d\TH:i', $value, wp_timezone() );
		return $date ? $date->getTimestamp() : 0;
	}
}
