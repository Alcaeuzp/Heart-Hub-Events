<?php
// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedNamespaceFound -- HeartHub is the established plugin vendor prefix; retain existing class names for integrations.
namespace HeartHub\EventRegistrations;

defined( 'ABSPATH' ) || exit;

final class Admin_Page {
	public const MENU_SLUG = 'heart-hub-event-registrations';

	private $settings;
	private $registrations;
	private $email;
	private $events;
	private $attendance;
	private $checkin_page;
	private $analytics;
	private $support_groups;
	private $hook_suffix = '';
	private $email_hook_suffix = '';
	private $create_event_hook_suffix = '';
	private $events_hook_suffix = '';
	private $fundraisers_hook_suffix = '';
	private $categories_hook_suffix = '';
	private $attendance_hook_suffix = '';
	private $checkin_page_hook_suffix = '';
	private $feedback_hook_suffix = '';
	private $settings_hook_suffix = '';
	private $registration_hook_suffix = '';
	private $support_groups_hook_suffix = '';
	private $support_group_editor_hook_suffix = '';

	public function __construct( Settings $settings, Registrations_Page $registrations, Email_Page $email, Event_Manager $events, Attendance_Manager $attendance, Checkin_Page $checkin_page, Analytics_Page $analytics, Support_Groups $support_groups ) {
		$this->settings     = $settings;
		$this->registrations = $registrations;
		$this->email         = $email;
		$this->events        = $events;
		$this->attendance    = $attendance;
		$this->checkin_page  = $checkin_page;
		$this->analytics     = $analytics;
		$this->support_groups = $support_groups;
	}

	public function register(): void {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	public function add_menu(): void {
		$this->hook_suffix = (string) add_menu_page( 'Heart Hub Events', 'Heart Hub Events', Plugin::CAPABILITY, self::MENU_SLUG, array( $this->registrations, 'render' ), 'dashicons-groups', 26 );
		$this->registration_hook_suffix = (string) add_submenu_page( self::MENU_SLUG, 'Registrations', 'Registrations', Plugin::CAPABILITY, self::MENU_SLUG, array( $this->registrations, 'render' ) );
		$this->attendance_hook_suffix = (string) add_submenu_page( self::MENU_SLUG, 'Attendance and Check-in', 'Attendance & Check-in', Plugin::CAPABILITY, Attendance_Manager::PAGE_SLUG, array( $this->attendance, 'render' ) );
		$this->checkin_page_hook_suffix = (string) add_submenu_page( null, 'Check-in Page', 'Check-in Page', Plugin::CAPABILITY, Checkin_Manager::CHECKIN_PAGE_SLUG, array( $this->checkin_page, 'render' ) );
		$this->feedback_hook_suffix = (string) add_submenu_page( self::MENU_SLUG, 'Event Feedback and Analytics', 'Feedback & Analytics', Plugin::CAPABILITY, Checkin_Manager::PAGE_SLUG, array( $this->analytics, 'render' ) );
		$this->events_hook_suffix = (string) add_submenu_page( self::MENU_SLUG, 'Manage Events', 'Events', Plugin::CAPABILITY, Event_Manager::LIST_PAGE_SLUG, array( $this->events, 'render_list' ) );
		$this->fundraisers_hook_suffix = (string) add_submenu_page( self::MENU_SLUG, 'Manage Fundraisers', 'Fundraisers', Plugin::CAPABILITY, Event_Manager::FUNDRAISER_LIST_PAGE_SLUG, array( $this->events, 'render_fundraisers' ) );
		$this->support_groups_hook_suffix = (string) add_submenu_page( self::MENU_SLUG, 'Manage Support Groups', 'Support Groups', Plugin::CAPABILITY, Support_Groups::PAGE_SLUG, array( $this->support_groups, 'render_list' ) );
		$this->support_group_editor_hook_suffix = (string) add_submenu_page( null, 'Create or Edit Support Programme', 'Support Programme', Plugin::CAPABILITY, Support_Groups::EDIT_PAGE_SLUG, array( $this->support_groups, 'render_editor' ) );
		$this->create_event_hook_suffix = (string) add_submenu_page( null, 'Create or Edit Heart Hub Event', 'Create Event', Plugin::CAPABILITY, Event_Manager::PAGE_SLUG, array( $this->events, 'render' ) );
		$this->categories_hook_suffix = (string) add_submenu_page( null, 'Manage Event Categories', 'Event Categories', 'manage_options', Event_Manager::CATEGORY_PAGE_SLUG, array( $this->events, 'render_categories' ) );
		$this->settings_hook_suffix = (string) add_submenu_page( self::MENU_SLUG, 'Heart Hub Registration Settings', 'Settings', 'manage_options', 'hherm', array( $this, 'render_settings' ) );
		$this->email_hook_suffix = (string) add_submenu_page( null, 'Heart Hub Decision Email Templates', 'Email Templates', 'manage_options', 'hherm-email-templates', array( $this->email, 'render' ) );
	}

	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only tab selection on a capability-protected admin route; saves use Settings API nonces.
	public function render_settings(): void {
		$tabs = array(
			'emails'         => 'Emails',
			'appearance'     => 'Appearance',
			'contact-access' => 'Contact & Access',
			'event-setup'    => 'Event Setup',
			'shortcodes'     => 'Shortcodes',
		);
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'emails';
		if ( ! isset( $tabs[ $tab ] ) ) $tab = 'emails';
		?>
		<div class="wrap hherm-settings-wrap">
			<header class="hherm-page-header"><div><span class="hherm-eyebrow">Heart Hub Events</span><h1>Settings</h1><p>Manage email delivery, appearance, access, event configuration, and front-end shortcodes.</p></div></header>
			<nav class="hherm-settings-tabs" aria-label="Settings sections">
			<?php foreach ( $tabs as $slug => $label ) : ?>
				<a class="<?php echo $slug === $tab ? 'is-active' : ''; ?>" href="<?php echo esc_url( add_query_arg( array( 'page' => 'hherm', 'tab' => $slug ), admin_url( 'admin.php' ) ) ); ?>" <?php echo $slug === $tab ? 'aria-current="page"' : ''; ?>><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
			</nav>
			<?php settings_errors(); ?>
			<?php $this->settings->render( $tab ); ?>
			<?php if ( 'emails' === $tab ) $this->email->render( true ); ?>
			<?php if ( 'event-setup' === $tab ) $this->events->render_categories( true ); ?>
		</div>
		<?php
	}
	// phpcs:enable WordPress.Security.NonceVerification.Recommended

	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only admin asset selection; registration data and changes use the capability/nonce-protected REST API.
	public function enqueue_assets( string $hook_suffix ): void {
		$known_hooks = array( $this->hook_suffix, $this->registration_hook_suffix, $this->email_hook_suffix, $this->create_event_hook_suffix, $this->events_hook_suffix, $this->fundraisers_hook_suffix, $this->support_groups_hook_suffix, $this->support_group_editor_hook_suffix, $this->categories_hook_suffix, $this->attendance_hook_suffix, $this->checkin_page_hook_suffix, $this->feedback_hook_suffix, $this->settings_hook_suffix );
		if ( ! in_array( $hook_suffix, $known_hooks, true ) ) {
			return;
		}

		wp_enqueue_style( 'hherm-admin-base', HHERM_URL . 'assets/admin-base.css', array(), HHERM_VERSION );
		$is_registration = in_array( $hook_suffix, array( $this->hook_suffix, $this->registration_hook_suffix ), true );
		if ( $is_registration ) {
			wp_enqueue_style( 'hherm-registrations', HHERM_URL . 'assets/registrations-page.css', array( 'hherm-admin-base' ), HHERM_VERSION );
			wp_enqueue_script( 'hherm-dashboard', HHERM_URL . 'assets/dashboard.js', array(), HHERM_VERSION, true );
			wp_localize_script( 'hherm-dashboard', 'HHERM', array( 'root' => esc_url_raw( rest_url( 'heart-hub/v1/applications' ) ), 'nonce' => wp_create_nonce( 'wp_rest' ), 'registrationId' => isset( $_GET['registration_id'] ) ? absint( wp_unslash( $_GET['registration_id'] ) ) : 0 ) );
			return;
		}
		if ( $hook_suffix === $this->attendance_hook_suffix ) {
			wp_enqueue_style( 'hherm-attendance', HHERM_URL . 'assets/attendance.css', array( 'hherm-admin-base' ), HHERM_VERSION );
			wp_enqueue_style( 'hherm-checkin-page', HHERM_URL . 'assets/checkin-page.css', array( 'hherm-admin-base' ), HHERM_VERSION );
			wp_enqueue_script( 'hherm-qrcode', HHERM_URL . 'assets/vendor/qrcode.min.js', array(), '1.0.0', true );
			wp_enqueue_script( 'hherm-checkin-admin', HHERM_URL . 'assets/checkin-admin.js', array( 'hherm-qrcode' ), HHERM_VERSION, true );
			wp_enqueue_script( 'hherm-checkin-page', HHERM_URL . 'assets/checkin-page.js', array(), HHERM_VERSION, true );
			wp_localize_script( 'hherm-checkin-page', 'HHERM_CHECKIN', array( 'root' => esc_url_raw( rest_url( 'heart-hub/v1' ) ), 'nonce' => wp_create_nonce( 'wp_rest' ) ) );
			return;
		}
		if ( $hook_suffix === $this->checkin_page_hook_suffix ) {
			wp_enqueue_style( 'hherm-checkin-page', HHERM_URL . 'assets/checkin-page.css', array( 'hherm-admin-base' ), HHERM_VERSION );
			wp_enqueue_script( 'hherm-checkin-page', HHERM_URL . 'assets/checkin-page.js', array(), HHERM_VERSION, true );
			wp_localize_script( 'hherm-checkin-page', 'HHERM_CHECKIN', array( 'root' => esc_url_raw( rest_url( 'heart-hub/v1' ) ), 'nonce' => wp_create_nonce( 'wp_rest' ) ) );
			return;
		}
		if ( $hook_suffix === $this->feedback_hook_suffix ) {
			wp_enqueue_style( 'hherm-analytics', HHERM_URL . 'assets/analytics.css', array( 'hherm-admin-base' ), HHERM_VERSION );
			wp_enqueue_script( 'hherm-analytics', HHERM_URL . 'assets/analytics.js', array(), HHERM_VERSION, true );
			return;
		}
		if ( in_array( $hook_suffix, array( $this->support_groups_hook_suffix, $this->support_group_editor_hook_suffix ), true ) ) {
			wp_enqueue_style( 'hherm-support-groups-admin', HHERM_URL . 'assets/support-groups-admin.css', array( 'hherm-admin-base' ), HHERM_VERSION );
			return;
		}
		if ( $hook_suffix === $this->email_hook_suffix ) {
			wp_enqueue_media();
			wp_enqueue_style( 'hherm-email-page', HHERM_URL . 'assets/email-page.css', array( 'hherm-admin-base' ), HHERM_VERSION );
			wp_enqueue_script( 'hherm-email-settings', HHERM_URL . 'assets/email-settings.js', array(), HHERM_VERSION, true );
			return;
		}
		if ( $hook_suffix === $this->create_event_hook_suffix ) {
			wp_enqueue_style( 'hherm-event-editor', HHERM_URL . 'assets/event-editor.css', array( 'hherm-admin-base' ), HHERM_VERSION );
			$map_config = $this->events->map_api_config();
			$event_editor_dependencies = array();
			if ( ! empty( $map_config['script_url'] ) ) {
				wp_enqueue_script( 'hherm-google-maps', esc_url_raw( $map_config['script_url'] ), array(), HHERM_VERSION, true );
				$event_editor_dependencies[] = 'hherm-google-maps';
			}
			wp_enqueue_script( 'hherm-event-editor', HHERM_URL . 'assets/event-editor.js', $event_editor_dependencies, HHERM_VERSION, true );
			wp_localize_script( 'hherm-event-editor', 'HHERM_EVENT_EDITOR', array( 'addressAutocomplete' => ! empty( $map_config['script_url'] ) ) );
			return;
		}
		if ( in_array( $hook_suffix, array( $this->events_hook_suffix, $this->fundraisers_hook_suffix, $this->categories_hook_suffix ), true ) ) {
			wp_enqueue_script( 'hherm-events', HHERM_URL . 'assets/events.js', array(), HHERM_VERSION, true );
			if ( in_array( $hook_suffix, array( $this->events_hook_suffix, $this->fundraisers_hook_suffix ), true ) && ! empty( $_GET['event_id'] ) ) {
				wp_enqueue_style( 'hherm-registrations', HHERM_URL . 'assets/registrations-page.css', array( 'hherm-admin-base' ), HHERM_VERSION );
				wp_enqueue_script( 'hherm-dashboard', HHERM_URL . 'assets/dashboard.js', array(), HHERM_VERSION, true );
				wp_localize_script( 'hherm-dashboard', 'HHERM', array( 'root' => esc_url_raw( rest_url( 'heart-hub/v1/applications' ) ), 'nonce' => wp_create_nonce( 'wp_rest' ) ) );
			}

			wp_enqueue_style( 'hherm-events', HHERM_URL . 'assets/events.css', array( 'hherm-admin-base' ), HHERM_VERSION );
			return;
		}
		if ( $hook_suffix === $this->settings_hook_suffix ) {
			wp_enqueue_media();
			wp_enqueue_style( 'hherm-settings', HHERM_URL . 'assets/settings.css', array( 'hherm-admin-base' ), HHERM_VERSION );
			wp_enqueue_script( 'hherm-email-settings', HHERM_URL . 'assets/email-settings.js', array(), HHERM_VERSION, true );
			$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'emails';
			if ( ! in_array( $tab, array( 'emails', 'appearance', 'contact-access', 'event-setup', 'shortcodes' ), true ) ) $tab = 'emails';
			if ( 'emails' === $tab ) {
				wp_enqueue_style( 'hherm-email-page', HHERM_URL . 'assets/email-page.css', array( 'hherm-admin-base' ), HHERM_VERSION );
			}
			if ( 'event-setup' === $tab ) {
				wp_enqueue_style( 'hherm-events', HHERM_URL . 'assets/events.css', array( 'hherm-admin-base' ), HHERM_VERSION );
				wp_enqueue_script( 'hherm-events', HHERM_URL . 'assets/events.js', array(), HHERM_VERSION, true );
			}
			wp_enqueue_style( 'hherm-settings-tabs', HHERM_URL . 'assets/settings-tabs.css', array( 'hherm-settings' ), HHERM_VERSION );
		}
	}
	// phpcs:enable WordPress.Security.NonceVerification.Recommended
}
