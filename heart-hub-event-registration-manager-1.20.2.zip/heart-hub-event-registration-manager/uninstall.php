<?php
/**
 * Uninstall Heart Hub Event Registration Manager.
 *
 * Removes only data owned by this plugin. Existing JetEngine CCT items,
 * Events posts, relations, forms, pages, queries, and listings are preserved.
 *
 * @package HeartHubEventRegistrationManager
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

/**
 * Remove plugin-owned data for the current site.
 */
function hherm_uninstall_site(): void {
	global $wpdb;

	delete_option( 'hherm_settings' );
	delete_option( 'hherm_owner_roles' );
	delete_option( 'hherm_email_templates' );
	delete_option( 'hherm_email_automation' );
	delete_option( 'hherm_public_page_settings' );
	delete_option( 'hherm_scheduled_email_jobs' );
	delete_transient( 'hherm_feedback_cron_lock' );
	wp_clear_scheduled_hook( 'hherm_send_feedback_reminders' );
	wp_clear_scheduled_hook( 'hherm_categorize_past_events' );
	wp_unschedule_hook( 'hherm_send_scheduled_email', true );

	foreach ( array_keys( wp_roles()->roles ) as $role_name ) {
		$role = get_role( $role_name );
		if ( $role ) {
			$role->remove_cap( 'manage_heart_hub_event_registrations' );
		}
	}

	$lock_pattern = $wpdb->esc_like( 'hherm_review_lock_' ) . '%';
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Removes only plugin-owned temporary options during uninstall.
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $lock_pattern ) );
	$capacity_lock_pattern = $wpdb->esc_like( 'hherm_capacity_lock_' ) . '%';
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Removes only plugin-owned temporary capacity locks during uninstall.
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $capacity_lock_pattern ) );
	$email_job_lock_pattern = $wpdb->esc_like( 'hherm_email_job_lock_' ) . '%';
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Removes only plugin-owned temporary email job locks during uninstall.
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $email_job_lock_pattern ) );
	$checkin_pattern = $wpdb->esc_like( 'hherm_checkin_event_' ) . '%';
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Removes only plugin-owned temporary check-in links during uninstall.
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $checkin_pattern ) );
	$manage_pattern = $wpdb->esc_like( 'hherm_registration_manage_' ) . '%';
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Removes only plugin-owned attendee self-service links during uninstall.
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $manage_pattern ) );
	$feedback_pattern = $wpdb->esc_like( 'hherm_feedback_link_' ) . '%';
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Removes only plugin-owned feedback links during uninstall.
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $feedback_pattern ) );
	foreach ( array( '_transient_hherm_ci_', '_transient_timeout_hherm_ci_' ) as $transient_prefix ) {
		$transient_pattern = $wpdb->esc_like( $transient_prefix ) . '%';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Removes only plugin-owned check-in rate-limit transients during uninstall.
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $transient_pattern ) );
	}

	$audit_table = $wpdb->prefix . 'hherm_audit_log';
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange -- Uninstall removes only this plugin-owned audit table, including its personal data.
	$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $audit_table ) );
}

if ( is_multisite() ) {
	$hherm_site_ids = get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	);

	foreach ( $hherm_site_ids as $hherm_site_id ) {
		switch_to_blog( (int) $hherm_site_id );
		hherm_uninstall_site();
		restore_current_blog();
	}
} else {
	hherm_uninstall_site();
}
